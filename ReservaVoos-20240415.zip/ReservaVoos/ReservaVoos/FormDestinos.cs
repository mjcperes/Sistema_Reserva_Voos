﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ReservaVoos
{
    public partial class FormDestinos : Form
    {
        DBConnect ligacao = new DBConnect();
        public FormDestinos()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (ligacao.ContarDestino(txtIATA.Text) == 0)
                {
                    if (ligacao.InsertDestino(txtIATA.Text, txtCidade.Text))
                    {
                        MessageBox.Show("Gravado com sucesso!");
                        Limpar();
                        txtIATA.Focus();                    
                    }
                    else
                    {
                        MessageBox.Show("Erro na gravação do registo!");
                    }
                }
                else
                {
                    MessageBox.Show("Código IATA já existe!");
                }
            }
        }

        private bool VerificarCampos()
        {
            txtIATA.Text = Geral.TirarEspacos(txtIATA.Text);
            if (txtIATA.Text.Length != 3)
            {
                MessageBox.Show("Erro no campo Nome!");
                txtIATA.Focus();
                return false;
            }

            txtCidade.Text = Geral.TirarEspacos(txtCidade.Text);
            if (txtCidade.Text.Length < 3)
            {
                MessageBox.Show("Erro no campo Cidade!");
                txtCidade.Focus();
                return false;
            }

            return true;
        }

        private void Limpar()
        {            
            txtIATA.Text = "";
            txtCidade.Text = "";            
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (MessageBox.Show("Deseja atualizar o código IATA " + txtIATA.Text, "Atualizar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) ==
                DialogResult.Yes)
                {
                    if (ligacao.ContarDestino(txtIATA.Text) == 1)
                    {
                        if (ligacao.UpdateDestino(txtIATA.Text.ToUpper(), txtCidade.Text))
                        {
                            MessageBox.Show("Gravado com sucesso!");
                            Limpar();
                            txtIATA.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Erro na gravação do registo!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Código IATA não existe!");
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            // groupBox1.Enabled = true;
            Limpar();
            txtIATA.Focus();
        }

        private void txtIATA_KeyPress(object sender, KeyPressEventArgs e)
        {
            string nome_Cidade = "";

            if (e.KeyChar == (Char)Keys.Enter) // pesquisa é ativada pressionando a tecla enter
            {
                // Para evitar o beep depois do Enter:

                e.Handled = true; // indica que o processo de pressionar a tecla enter foi terminado e para passar processos subsequentes sem os ativar
                // e.SuppressKeyPress = true; // previne que o evento keyPress seja despoletado depois do keyDown (no caso de se usar keyDown)

                if (ligacao.PesquisarDestino(txtIATA.Text, ref nome_Cidade))
                {
                    txtCidade.Text = nome_Cidade;
                }
                else
                {
                    MessageBox.Show("Código IATA não encontrado!");
                    Limpar();
                }
            }
        }
    }
}
