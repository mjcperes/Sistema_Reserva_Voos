﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReservaVoos
{
    public partial class FormListarRotas : Form
    {
        DBConnect ligacao = new DBConnect();
        public FormListarRotas()
        {
            InitializeComponent();
        }

        private void FormListarRotas_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Columns.Add("id_Rota", "ID Rota");
            dataGridView1.Columns.Add("aeropPartida", "Origem");
            dataGridView1.Columns.Add("aeropChegada", "Destino");
            dataGridView1.Columns.Add("distancia", "Distância (Kms)");
            dataGridView1.Columns.Add("tarifa_OW", "Tarifa OW");
            dataGridView1.Columns.Add("tarifa_RT", "Tarifa RT");

            ligacao.PreencherDataGridViewRotas(ref dataGridView1);

            lblRegistos.Text = "Nº Registos: " + dataGridView1.RowCount.ToString();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            ligacao.PreencherDataGridViewRotas(ref dataGridView1);

            lblRegistos.Text = "Nº Registos: " + dataGridView1.RowCount.ToString();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
