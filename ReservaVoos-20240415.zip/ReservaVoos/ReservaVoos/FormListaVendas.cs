﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReservaVoos
{
    public partial class FormListaVendas : Form
    {
        DBConnect ligacao = new DBConnect();
        float total = 0;

        public FormListaVendas()
        {
            InitializeComponent();
        }

        private void FormListaVendas_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Columns.Add("ID Voo", "Nº Voo");
            dataGridView1.Columns.Add("idPax", "Doc Id");
            dataGridView1.Columns.Add("NumBilhete", "Bilhete");
            dataGridView1.Columns.Add("dataTkt", "Data Tkt");
            dataGridView1.Columns.Add("Tarifa", "Tarifa");
            dataGridView1.Columns.Add("Receita", "Receita");
            


            ligacao.PreencherComboIdVoo(ref cbxIdVoo);

            ligacao.PreencherDataGridViewVendas(ref dataGridView1, cbxIdVoo.Text);

            lblVendas.Visible = false;


            this.AcceptButton = this.btnPesquisar; // botão pode ser pressionado com a tecla enter
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            total = 0;

            dataGridView1.Rows.Clear();

            cbxIdVoo.Items.Clear();
            ligacao.PreencherComboIdVoo(ref cbxIdVoo);

            ligacao.PreencherDataGridViewVendas(ref dataGridView1, cbxIdVoo.Text);            

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["Receita"].Value != null && !string.IsNullOrEmpty(row.Cells["Receita"].Value.ToString()))
                {
                    total = total + Convert.ToSingle(row.Cells["Receita"].Value);
                }
            }

            lblVendas.Visible = true;
            lblVendas.Text = "Vendas Totais: EUR " + total.ToString("F2");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
