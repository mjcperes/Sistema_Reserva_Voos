﻿//using iTextSharp.text.pdf;
//using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ReservaVoos
{
    public partial class FormReservaDeVoo : Form
    {
        DBConnect ligacao = new DBConnect();
        float total = 0;
        string auxPais = "";

        public FormReservaDeVoo()
        {
            InitializeComponent();
        }

        private void FormReservaDeVoo_Load(object sender, EventArgs e)
        {
            DesativarControlos();

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Columns.Add("ID Voo", "Nº Voo");            
            dataGridView1.Columns.Add("aeropPartida", "Origem");
            dataGridView1.Columns.Add("aeropChegada", "Destino");
            dataGridView1.Columns.Add("dataVoo", "Data");
            dataGridView1.Columns.Add("horaPartida", "Partida (UTC)");
            dataGridView1.Columns.Add("horaChegada", "Chegada (UTC)");
            dataGridView1.Columns.Add("tarifa", "Tarifa");
            dataGridView1.Columns.Add("Subtotal", "Subtotal");
            
        }

        private void DesativarControlos()
        {
            gbxSelecaoVoos.Enabled = true;
            cbxOrigem.Text = string.Empty;
            cbxOrigem.Items.Clear();
            ligacao.PreencherComboOrigem(ref cbxOrigem);
            cbxDestino.Text = string.Empty;
            cbxDestino.Items.Clear();
            rbIda.Checked = false;
            rbIdaVolta.Checked = false;
            lblDataVolta.Visible = false;
            cbxDataVolta.Visible = false;
            cbxDataVolta.Text = string.Empty;
            lblDataIda.Visible = false;
            cbxDataIda.Visible = false;
            cbxDataIda.Text = string.Empty;
            btnSelecionarVoo.Visible = false;
            btnPesquisarDatas.Visible = true;
            gbxItinerario.Visible = false;
            gbxDados.Visible = false;
            lblTotalPagar.Visible = false;
            lblInfo.Visible = false;
            btnImprimir.Visible = false;            
            btnConfirmar.Visible = false;            
            total = 0;
        }

        private void cbxOrigem_SelectedIndexChanged(object sender, EventArgs e)
        {
            //cada vez que há uma alteração na cbxOrigem atualiza os dados no cbxDestino
            cbxDestino.Text = string.Empty;
            cbxDestino.Items.Clear();
            ligacao.PreencherComboDestino(ref cbxDestino, cbxOrigem.Text);
            
        }

        private char TipoPercurso()
        {
            char tpPercurso = 'T';

            if (rbIda.Checked)
            {
                tpPercurso = 'I';
            }
            else if (rbIdaVolta.Checked)
            {
                tpPercurso = 'V';
            }            
            return tpPercurso;
        }

        private void btnPesquisarDatas_Click(object sender, EventArgs e)
        {
            if (VerificarCamposPesquisarDatas())
            {
                cbxDataIda.Text = string.Empty;
                cbxDataIda.Items.Clear();
                ligacao.PreencherComboDataIda(ref cbxDataIda, cbxOrigem.Text, cbxDestino.Text);
                cbxDataVolta.Text = string.Empty;
                cbxDataVolta.Items.Clear();
                lblDataIda.Visible = true;
                cbxDataIda.Visible = true;
                btnSelecionarVoo.Visible = true;
            }
            if (TipoPercurso() == 'V')
            {
                lblDataVolta.Visible = true;
                cbxDataVolta.Visible = true;
            }
            else if (TipoPercurso() == 'I')
            {
                lblDataVolta.Visible = false;
                cbxDataVolta.Visible = false;
            }

            txtNumBilhete.Text = "";
        }

        private bool VerificarCamposPesquisarDatas()
        {
            if (cbxOrigem.Text.Length == 0 || cbxOrigem.Items.Contains(cbxOrigem.Text) == false)
            {
                MessageBox.Show("Erro no campo Origem!");
                cbxOrigem.Focus();
                return false;
            }

            if (cbxDestino.Text.Length == 0 || cbxDestino.Items.Contains(cbxDestino.Text) == false)
            {
                MessageBox.Show("Erro no campo Destino!");
                cbxOrigem.Focus();
                return false;
            }

            if (TipoPercurso() == 'T')
            {
                MessageBox.Show("Selecione o tipo de percurso (Só Ida / Ida e volta)!");
                rbIda.Focus();
                return false;
            }

            return true;
        }

        private bool VerificarCamposSelecionar()
        {
            if (cbxDataIda.Text.Length == 0 || cbxDataIda.Items.Contains(cbxDataIda.Text) == false)
            {
                MessageBox.Show("Erro no campo Data Ida!");
                cbxDataIda.Focus();
                return false;
            }            

            if (TipoPercurso() == 'V' && (cbxDataVolta.Text.Length == 0 || cbxDataVolta.Items.Contains(cbxDataVolta.Text) == false))
            {
                MessageBox.Show("Erro no campo Data Volta!");
                cbxDataVolta.Focus();
                return false;
            }

            return true;
        }

        private void cbxDataIda_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxDataVolta.Text = string.Empty;
            cbxDataVolta.Items.Clear();
            ligacao.PreencherComboDataVolta(ref cbxDataVolta, cbxDestino.Text, cbxOrigem.Text, DateTime.Parse(cbxDataIda.Text).ToString("yyyy-MM-dd"));
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            DesativarControlos();
        }

        private void btnSelecionarVoo_Click(object sender, EventArgs e)
        {
            if (VerificarCamposPesquisarDatas() && VerificarCamposSelecionar())
            {
                gbxSelecaoVoos.Enabled = false;
                gbxItinerario.Visible = true;
                gbxDados.Visible = true;


                //Preenchimento da datagridview com os voos selecionados
                dataGridView1.Rows.Clear();

                string origem = cbxOrigem.Text;
                string destino = cbxDestino.Text;
                string dataIda = DateTime.Parse(cbxDataIda.Text).ToString("yyyy-MM-dd");
                string dataVolta;
                if (TipoPercurso() != 'V')
                {
                    dataVolta = string.Empty;
                }
                else
                {
                    dataVolta = DateTime.Parse(cbxDataVolta.Text).ToString("yyyy-MM-dd");
                }                

                ligacao.PreencherDataGridViewItinerario(ref dataGridView1, origem, destino, dataIda, dataVolta, TipoPercurso());
                
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["Subtotal"].Value != null && !string.IsNullOrEmpty(row.Cells["Subtotal"].Value.ToString()))
                    {
                        total = total + Convert.ToSingle(row.Cells["Subtotal"].Value);
                    }                    
                }

                lblTotalPagar.Visible = true;
                lblTotalPagar.Text = "Total a pagar: EUR " + total.ToString("F2");

                cbxPais.Items.Clear();
                ligacao.PreencherComboPais(ref cbxPais);

                cbxTitulo.Items.Clear();
                cbxTitulo.Items.Add("Mr");
                cbxTitulo.Items.Add("Mrs");
                cbxTitulo.Items.Add("Ms");
                cbxTitulo.Items.Add("Chld");
                cbxTitulo.Items.Add("Inft");

                btnConfirmar.Visible = true;

            }
        }

        //Botão confirmar Reserva
        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            if (VerificarCamposDadosPax())
            {
                bool sucesso = false;

                if (ligacao.InsertPax(txtDocId.Text, txtNome.Text, auxPais, cbxTitulo.Text,
                    DateTime.Parse(mtxtDataNascimento.Text).ToString("yyyy-MM-dd"), txtEmail.Text))
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        string idVoo = row.Cells["ID Voo"].Value.ToString();
                        string idTarifa = row.Cells["tarifa"].Value.ToString();

                        if (ligacao.InsertVendas(DateTime.Now.ToString("yyyy-MM-dd"), txtDocId.Text, idTarifa, idVoo))
                        {
                            sucesso = true;
                        }
                        else { sucesso = false; }
                    }
                }
                else { MessageBox.Show("Erro na gravação dos dados do passageiro!"); }                
                
                if (sucesso)
                {
                    MessageBox.Show("Reserva efetuada com sucesso!\n\nIrá receber um email com os dados para pagamento.");
                    btnImprimir.Visible = true; btnConfirmar.Visible = false;
                    btnPesquisarDatas.Visible = false;
                    gbxDados.Enabled = false;
                    lblInfo.Visible = true;
                    txtNumBilhete.Text = ligacao.DevolveNumeroBilhete().ToString();
                }
                else { MessageBox.Show("Erro na gravação do registo!"); }

            }
        }

        private bool VerificarCamposDadosPax()
        {
            if (txtNome.Text.Length < 3)
            {
                MessageBox.Show("Erro no campo Nome!");
                txtNome.Focus();
                return false;
            }

            if (cbxPais.Text.Length == 0 || cbxPais.Items.Contains(cbxPais.Text) == false)
            {
                MessageBox.Show("Erro no campo País!");
                cbxPais.Focus();
                return false;
            }
            else 
            {                
                auxPais = cbxPais.Text.Split('-')[0].Trim();
            }


            if (txtDocId.Text.Length < 6)
            {
                MessageBox.Show("Erro no campo Doc ID / CC!");
                txtDocId.Focus();
                return false;
            }

            if (mtxtDataNascimento.Text.Length != 10 || Geral.CheckDate(mtxtDataNascimento.Text) == false)
            {
                MessageBox.Show("Erro no campo Data de Nascimento!");
                mtxtDataNascimento.Focus();
                return false;
            }

            if (cbxTitulo.Text.Length != 0 && cbxTitulo.Items.Contains(cbxTitulo.Text) == false)
            {
                MessageBox.Show("Erro no campo Título!");
                cbxTitulo.Focus();
                return false;
            }
            else if (cbxTitulo.Text.Length == 0)
            {
                cbxTitulo.Text = string.Empty;
            }

            if (txtEmail.Text.Length < 7 && txtEmail.Text.IndexOf('@') == -1)
            {
                MessageBox.Show("Erro no campo Email!");
                cbxPais.Focus();
                return false;
            }

            return true;
        }

        // Impressão da Reserva
        private void btnImprimir_Click(object sender, EventArgs e)
        {
            // Obtem a localização do FormReservaDeVoo no FormPrincipal
            Point formLocation = ((FormPrincipal)this.ParentForm).GetFormReservaDeVooLocation();

            // Captura o form como uma imagem
            Bitmap memoryImage;
            Graphics myGraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            // memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);
            memoryGraphics.CopyFromScreen(formLocation.X, formLocation.Y, -100, 0, s);
            

            // Imprime a imagem para pdf
            PrintDocument printDocument1 = new PrintDocument();
            printDocument1.PrintPage += (sender2, e2) =>
            {
                e2.Graphics.DrawImage(memoryImage, 0, 0);
            };
            printDocument1.Print();            
        }

        private void btnPesquisarNumBilhete_Click(object sender, EventArgs e)
        {            
            DesativarControlos();
            gbxSelecaoVoos.Visible = true;
            gbxItinerario.Visible = true;
            gbxDados.Visible = true;            
            
            lblDataIda.Visible = true;
            cbxDataIda.Visible = true;

            gbxSelecaoVoos.Enabled = true;
            gbxDados.Enabled = true;

            string origem = "", destino = "", tipoPercurso = "", dataIda = "", dataVolta = string.Empty, nome = "", docId = "",
                titulo = string.Empty, pais = "",  dataNascimento = "", email = "", auxDataVolta = string.Empty;
            
            if (ligacao.PesquisarBilhete(txtNumBilhete.Text, ref origem, ref destino, ref tipoPercurso, ref dataIda,
                ref nome, ref docId, ref titulo, ref pais, ref dataNascimento, ref email))
                {
                cbxOrigem.Text = origem;
                cbxDestino.Text = destino;
                cbxDataIda.Text = dataIda;
                txtNome.Text = nome;
                txtDocId.Text = docId;
                cbxTitulo.Text = titulo;
                cbxPais.Text = pais;
                mtxtDataNascimento.Text = dataNascimento;
                txtEmail.Text = email;


                if (tipoPercurso == "OW")
                {
                    rbIda.Checked = true;
                }
                else if (tipoPercurso == "RT")
                {
                    rbIdaVolta.Checked = true;
                    lblDataVolta.Visible = true;
                    cbxDataVolta.Visible = true;
                    ligacao.PesquisarBilheteDataVolta(txtNumBilhete.Text, ref dataVolta);
                    cbxDataVolta.Text = dataVolta;
                    auxDataVolta = DateTime.Parse(dataVolta).ToString("yyyy-MM-dd");
                }                

                dataGridView1.Rows.Clear();
                ligacao.PreencherDataGridViewItinerario(ref dataGridView1, origem, destino, DateTime.Parse(dataIda).ToString("yyyy-MM-dd"),
                    auxDataVolta, tipoPercurso, docId);

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["Subtotal"].Value != null && !string.IsNullOrEmpty(row.Cells["Subtotal"].Value.ToString()))
                    {
                        total = total + Convert.ToSingle(row.Cells["Subtotal"].Value);
                    }
                }

                lblTotalPagar.Visible = true;
                lblTotalPagar.Text = "Total a pagar: EUR " + total.ToString("F2");

            }
            else
            {
                MessageBox.Show("Número de bilhete não encontrado!");
                txtNumBilhete.Text = "";
                DesativarControlos();
            }

            gbxSelecaoVoos.Enabled = false;
            gbxDados.Enabled = false;

            btnImprimir.Visible = true; btnConfirmar.Visible = false;
            btnPesquisarDatas.Visible = false;            
            lblInfo.Visible = true;         
        }
    }
}
