﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReservaVoos
{
    public partial class FormVoos : Form
    {
        DBConnect ligacao = new DBConnect();
        private string auxIdRota = "";
        private string auxMatricula = "";
        private string auxDtVoo = "";        

        public FormVoos()
        {
            InitializeComponent();
        }

        private void FormVoos_Load(object sender, EventArgs e)
        {
            txtIdVoo.Text = ligacao.DevolveUltimoIdVoo().ToString();
            ligacao.PreencherComboIdRota(ref cbxIdRota); // Preenchimento da comboBox
            ligacao.PreencherComboMatricula(ref cbxMatricula); // Preenchimento da comboBox
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (int.Parse(txtIdVoo.Text) >= ligacao.DevolveUltimoIdVoo()) //Verifica se ID Voo já existe
                {
                    bool valida = true;

                    // Verifica se existem voos na mesma rota e data
                    if (ligacao.ValidateVoo(auxIdRota, DateTime.Parse(auxDtVoo).ToString("yyyy-MM-dd")) &&
                        MessageBox.Show("Existe(m) voo(s) na mesma rota e data. Deseja inserir novo voo?", "Inserir Voo",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
                    {
                        valida = false;
                        txtIdVoo.Focus();
                    }
                    if (valida)
                    {
                        if (ligacao.InsertVoos(auxIdRota, auxMatricula, DateTime.Parse(auxDtVoo).ToString("yyyy-MM-dd"),
                        DateTime.Parse(mtxtHoraPartida.Text).ToString("HH:mm"), DateTime.Parse(mtxtHoraChegada.Text).ToString("HH:mm"), Estado(), txtNumLugares.Text))
                        {
                            MessageBox.Show("Voo inserido com sucesso!");
                            Limpar();
                            txtIdVoo.Focus();

                            // apaga os itens após cada operação com a combobox
                            // Pode ser colocado aqui ou no método em DBConnet (cbx.Items.Clear();)                        
                            cbxIdRota.Items.Clear();
                            cbxMatricula.Items.Clear();

                            ligacao.PreencherComboIdRota(ref cbxIdRota); // se apagar é feito o refresh da ligação
                            ligacao.PreencherComboMatricula(ref cbxMatricula); // se apagar é feito o refresh da ligação
                        }
                        else
                        {
                            MessageBox.Show("Erro na gravação do registo!");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("ID Voo já existe!");
                }
                
            }
        }

        private bool VerificarCampos()
        {
            if (int.TryParse(txtIdVoo.Text, out _) == false)
            {
                MessageBox.Show("Erro no campo ID Voo!\nTem de conter um número");
                txtIdVoo.Focus();
                return false;
            }

            // É verificada se a substring para o IdRota é igual aos itens disponíveis da cbxIdRota
            if (cbxIdRota != null)
            {
                auxIdRota = cbxIdRota.Text.Split('-')[0].Trim();
            }
            
            bool contemAuxIdRota = false;
            foreach (string s in cbxIdRota.Items)
            {
                if (s.ToString().Contains(auxIdRota) && auxIdRota != "")
                {
                    contemAuxIdRota = true;
                    break;
                }                
            }
            if (contemAuxIdRota == false)
            {                
                MessageBox.Show("Erro no campo ID Rota!");
                cbxIdRota.Focus();
                return false;
            }            
           
            // A cbxMatricula pode ter campo nulo. Se não for nulo tem de ser um dos itens disponíveis            
            if (cbxMatricula.Text.Length > 0 && cbxMatricula.Items.Contains(cbxMatricula.Text) == false)
            {
                MessageBox.Show("Erro no campo Matricula!");
                cbxMatricula.Focus();
                return false;
            }
            else if (cbxMatricula.Text != null)
            {
                auxMatricula = cbxMatricula.Text; // Na Pesquisa e atualização pode não ser usada a comboBox
            }
            else if (cbxMatricula.Text == null || cbxMatricula.Text == "")
            {
                auxMatricula = string.Empty;
            }
            
            if (mtxtHoraPartida.MaskCompleted == false || Geral.CheckTime(mtxtHoraPartida.Text) == false)
            {
                MessageBox.Show("Erro no campo Hora Partida!\nFormato HH:mm");
                mtxtHoraPartida.Focus();
                return false;
            }

            if (mtxtHoraChegada.MaskCompleted == false || Geral.CheckTime(mtxtHoraChegada.Text) == false)
            {
                MessageBox.Show("Erro no campo Hora Chegada!\nFormato HH:mm");
                mtxtHoraChegada.Focus();
                return false;
            }

            if (DateTime.Parse(mtxtHoraChegada.Text) < DateTime.Parse(mtxtHoraPartida.Text))
            {
                MessageBox.Show("Erro nos campos Hora Partida / Chegada!\nHora Chegada não pode ser inferior à Hora Partida!");
                mtxtHoraChegada.Focus();
                return false;
            }

            txtNumLugares.Text = Geral.TirarEspacos(txtNumLugares.Text);
            if (int.Parse(txtNumLugares.Text) < 1 || int.Parse(txtNumLugares.Text) > 180)
            {
                MessageBox.Show("Erro no campo Nº Lugares!\nTem de estar entre 1 e 180.");
                txtNumLugares.Focus();
                return false;
            }            

            if (Estado() == 'T')
            {
                MessageBox.Show("Erro no campo Estado!\nSelecione Planeado, Fechado ou Cancelado!");
                rbPlaneado.Focus();
                return false;
            }

            if (Estado() == 'F' && cbxMatricula.Text.Length == 0)
            {
                MessageBox.Show("Erro no campo Matricula!\n\nVoo fechado sem aeronave associada!");
                cbxMatricula.Focus();
                return false;
            }

            auxDtVoo = dtpDataVoo.Value.ToShortDateString();
            if (DateTime.Parse(auxDtVoo) < DateTime.Now && Estado() == 'P' || DateTime.Parse(auxDtVoo) > DateTime.Now && Estado() == 'F')
            {
                MessageBox.Show("Erro no campo Data Voo!\nSe voo Planeado data não pode ser inferior a hoje!" +
                    "\nSe voo Fechado data não pode ser no futuro");
                dtpDataVoo.Focus();
                return false;
            }

            return true;
        }

        private char Estado()
        {
            char estado = 'T';

            if (rbPlaneado.Checked)
            {
                estado = 'P';
            }
            else if (rbFechado.Checked)
            {
                estado = 'F';
            }
            else if (rbCancelado.Checked)
            {
                estado = 'C';
            }
            return estado;
        }

        private void Limpar()
        {
            txtIdVoo.Text = ligacao.DevolveUltimoIdVoo().ToString();
            cbxIdRota.Text = string.Empty;
            cbxMatricula.Text = "";
            dtpDataVoo.Value = DateTime.Now;
            mtxtHoraPartida.Clear();
            mtxtHoraChegada.Clear();
            txtNumLugares.Text = "";
            rbPlaneado.Checked = false;
            rbFechado.Checked = false;
            rbCancelado.Checked = false;            
        }

        private void dtpDataVoo_ValueChanged(object sender, EventArgs e)
        {
            auxDtVoo = dtpDataVoo.Value.ToShortDateString();
        }

        private void btnPesquisarIdVoo_Click(object sender, EventArgs e)
        {
            string idRota = string.Empty, matricula = string.Empty, dataVoo = string.Empty, horaPartida = "",
                horaChegada = "", numLugares = "";
            char estado = ' ';

            if (ligacao.PesquisarIdVoo(txtIdVoo.Text, ref idRota, ref matricula, ref dataVoo, ref horaPartida, ref horaChegada,
                ref estado, ref numLugares))
            {
                cbxIdRota.Text = idRota;
                cbxMatricula.Text = matricula;
                dtpDataVoo.Text = dataVoo;
                mtxtHoraPartida.Text = horaPartida;
                mtxtHoraChegada.Text = horaChegada;
                txtNumLugares.Text = numLugares;

                if (estado == 'P')
                {
                    rbPlaneado.Checked = true;
                }
                else if (estado == 'F')
                {
                    rbFechado.Checked = true;
                }
                else if (estado == 'C')
                {
                    rbCancelado.Checked = true;
                }                

                cbxIdRota.Items.Clear();
                cbxMatricula.Items.Clear();
                ligacao.PreencherComboIdRota(ref cbxIdRota); // Preenchimento das comboboxes
                ligacao.PreencherComboMatricula(ref cbxMatricula);
            }
            else
            {
                MessageBox.Show("Registo de voo não encontrado!");
                Limpar();
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (MessageBox.Show("Deseja atualizar o voo com o ID " + txtIdVoo.Text, "Atualizar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    if (ligacao.ValidateVoo(txtIdVoo.Text))
                    {
                        if (ligacao.UpdateVoos(txtIdVoo.Text, auxIdRota, auxMatricula, DateTime.Parse(auxDtVoo).ToString("yyyy-MM-dd"), 
                            DateTime.Parse(mtxtHoraPartida.Text).ToString("HH:mm"), DateTime.Parse(mtxtHoraChegada.Text).ToString("HH:mm"),
                            Estado(), txtNumLugares.Text))
                        {
                            MessageBox.Show("Gravado com sucesso!");
                            Limpar();
                            txtIdVoo.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Erro na gravação do registo!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("ID Voo não existe!");
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpar();
            txtIdVoo.Focus();
        }
    }
}
