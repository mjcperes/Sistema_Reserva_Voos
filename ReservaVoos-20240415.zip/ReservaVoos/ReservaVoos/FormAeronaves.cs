﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ReservaVoos
{
    public partial class FormAeronaves : Form
    {
        DBConnect ligacao = new DBConnect();

        public FormAeronaves()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (ligacao.ContarMatricula(txtMatricula.Text) == 0)
                {
                    if (ligacao.InsertAeronave(txtMatricula.Text.ToUpper(), txtMarcaModelo.Text, txtLotacao.Text, txtAutonomia.Text))
                    {
                        MessageBox.Show("Gravado com sucesso!");
                        Limpar();
                        txtMatricula.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Erro na gravação do registo!");
                    }
                }
                else
                {
                    MessageBox.Show("Matrícula já existe!");
                }
            }
        }

        private bool VerificarCampos()
        {
            txtMatricula.Text = Geral.TirarEspacos(txtMatricula.Text);
            if (txtMatricula.Text.Length < 6)
            {
                MessageBox.Show("Erro no campo Matrícula!");
                txtMatricula.Focus();
                return false;
            }

            txtMarcaModelo.Text = Geral.TirarEspacos(txtMarcaModelo.Text);
            if (txtMarcaModelo.Text.Length < 4)
            {
                MessageBox.Show("Erro no campo Marca e modelo!");
                txtMarcaModelo.Focus();
                return false;
            }

            txtLotacao.Text = Geral.TirarEspacos(txtLotacao.Text);
            bool verificaInt = int.TryParse(txtLotacao.Text, out _);
            if (txtLotacao.Text.Length < 1 || verificaInt == false)
            {
                MessageBox.Show("Erro no campo Lotacao!");
                txtLotacao.Focus();
                return false;
            }

            txtAutonomia.Text = Geral.TirarEspacos(txtAutonomia.Text);
            verificaInt = int.TryParse(txtAutonomia.Text, out _);
            if (txtAutonomia.Text.Length < 3 || verificaInt == false)
            {
                MessageBox.Show("Erro no campo Autonomia!");
                txtAutonomia.Focus();
                return false;
            }

            return true;
        }

        private void Limpar()
        {
            txtMatricula.Text = "";
            txtMarcaModelo.Text = "";
            txtLotacao.Text = "";
            txtAutonomia.Text = "";
        }

        private void btnPesquisarMatricula_Click(object sender, EventArgs e)
        {
            string marcaModelo = "", lotacao = "", autonomia = string.Empty;

            if (ligacao.PesquisarMatricula(txtMatricula.Text, ref marcaModelo, ref lotacao, ref autonomia))
            {
                txtMarcaModelo.Text = marcaModelo;
                txtLotacao.Text = lotacao;
                txtAutonomia.Text = autonomia;
            }
            else
            {
                MessageBox.Show("Matrícula não encontrada!");
                Limpar();
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (MessageBox.Show("Deseja atualizar a aeronave com a matrícula " + txtMatricula.Text, "Atualizar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) ==
                DialogResult.Yes)
                {
                    if (ligacao.ContarMatricula(txtMatricula.Text) == 1)
                    {
                        if (ligacao.UpdateAeronave(txtMatricula.Text, txtMarcaModelo.Text, txtLotacao.Text, txtAutonomia.Text))
                        {
                            MessageBox.Show("Gravado com sucesso!");
                            Limpar();
                            txtMatricula.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Erro na gravação do registo!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Matrícula não existe!");
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpar();
            txtMatricula.Focus();
        }
    }
}
