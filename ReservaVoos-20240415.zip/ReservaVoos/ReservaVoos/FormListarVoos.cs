﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReservaVoos
{
    public partial class FormListarVoos : Form
    {
        DBConnect ligacao = new DBConnect();
        string dataInicio = "", dataFim = "";

        public FormListarVoos()
        {
            InitializeComponent();
        }

        private void FormListarVoos_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Columns.Add("ID Voo", "Nº Voo");
            dataGridView1.Columns.Add("matricula", "Matrícula");
            dataGridView1.Columns.Add("aeropPartida", "Partida");
            dataGridView1.Columns.Add("aeropChegada", "Chegada");
            dataGridView1.Columns.Add("dataVoo", "Data");
            dataGridView1.Columns.Add("horaPartida", "Hora Partida (UTC)");
            dataGridView1.Columns.Add("horaChegada", "Hora Chegada (UTC)");
            dataGridView1.Columns.Add("Estado", "Estado");
            dataGridView1.Columns.Add("Nº Lugares", "Nº Lugares");
            dataGridView1.Columns.Add("Nº Pax", "Nº Pax");

            //ligacao.PreencherComboIdRota(ref cbxIdRota);
            //ligacao.PreencherComboMatricula(ref cbxMatricula);

            //ligacao.PreencherDataGridViewVoos(ref dataGridView1);

            //lblRegistos.Text = "Nº Registos: " + dataGridView1.RowCount.ToString();

            //rbTodos.Checked = true;
            //dtpDataVooInicio.Value = DateTime.Now.AddDays(-30);
            //dtpDataVooFim.Value = DateTime.Now.AddDays(30);

            btnRefresh_Click(sender, e); // clica no botão refresh - é desnecessário o código acima por estar repetido no btnRefresh_click

            this.AcceptButton = this.btnRefresh; // botão pode ser pressionado com a tecla enter
            this.AcceptButton = this.btnPesquisar; // botão pode ser pressionado com a tecla enter
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            cbxIdRota.Text = "";
            cbxMatricula.Text = "";
            rbTodos.Checked = true;
            
            dtpDataVooInicio.Value = DateTime.Now.AddDays(-30);
            dataInicio = DateTime.Parse(dtpDataVooInicio.Value.ToShortDateString()).ToString("yyyy-MM-dd");
            
            dtpDataVooFim.Value = DateTime.Now.AddDays(30);
            dataFim = DateTime.Parse(dtpDataVooFim.Value.ToShortDateString()).ToString("yyyy-MM-dd");

            //cbxIdRota.SelectedItem = null;
            cbxIdRota.Items.Clear();
            ligacao.PreencherComboIdRota(ref cbxIdRota);

            cbxMatricula.Items.Clear();
            ligacao.PreencherComboMatricula(ref cbxMatricula);

            ligacao.PreencherDataGridViewVoos(ref dataGridView1);

            lblRegistos.Text = "Nº Registos: " + dataGridView1.RowCount.ToString();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if (verificaDatas())
            {
                dataGridView1.Rows.Clear();
                                
                string matricula = cbxMatricula.Text;

                string aeropPartida = string.Empty;
                string aeropChegada = string.Empty;
                if (cbxIdRota.Text.Length > 0)
                {
                    try { aeropPartida = cbxIdRota.Text.Split('-')[1].Trim(); }
                    catch (Exception ex) { aeropPartida = "X"; } // Se a rota não for selecionada da combobox (input manual) a busca não dá resultados


                    try { aeropChegada = cbxIdRota.Text.Split('-')[2].Trim(); }
                    catch (Exception ex) { aeropChegada = "Y"; }
                }                

                ligacao.PreencherDataGridViewVoos(ref dataGridView1, matricula, dataInicio, dataFim, Estado(), aeropPartida, aeropChegada);

                lblRegistos.Text = "Nº Registos: " + dataGridView1.RowCount.ToString();
            }
            
        }

        private void dtpDataVooInicio_ValueChanged(object sender, EventArgs e)
        {
            //dataInicio = dtpDataVooInicio.Value.ToShortDateString();
            //dataInicio = DateTime.Parse(dataInicio).ToString("yyyy-MM-dd");
            dataInicio = DateTime.Parse(dtpDataVooInicio.Value.ToShortDateString()).ToString("yyyy-MM-dd");
        }

        private void dtpDataVooFim_ValueChanged(object sender, EventArgs e)
        {
            dataFim = dtpDataVooFim.Value.ToShortDateString();
            dataFim = DateTime.Parse(dataFim).ToString("yyyy-MM-dd");
        }

        private bool verificaDatas()
        {
            if (DateTime.Parse(dataInicio) > DateTime.Parse(dataFim))
            {
                MessageBox.Show("Data de início não pode ser posterior a data de fim!");
                dtpDataVooInicio.Focus();
                return false;
            }
            
            return true;
        }

        private char Estado()
        {
            char estado = 'T';

            if (rbPlaneado.Checked)
            {
                estado = 'P';
            }
            else if (rbFechado.Checked)
            {
                estado = 'F';
            }
            else if (rbCancelado.Checked)
            {
                estado = 'C';
            }
            return estado;
        }
    }
}
