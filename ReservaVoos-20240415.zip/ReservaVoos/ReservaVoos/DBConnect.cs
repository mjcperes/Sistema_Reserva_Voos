﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using Mysqlx.Crud;
using Org.BouncyCastle.Asn1.X509;

namespace ReservaVoos
{
    internal class DBConnect
    {
        private MySqlConnection connection;
        private string server;
        private string username;
        private string password;
        private string database;
        private string port;

        public DBConnect()
        {
            Initialize();
        }

        private void Initialize()
        {
            server = "192.168.1.70";
            username = "MarioP";
            password = "abc123!MP";
            database = "BDReservaVoos";
            port = "3306";
            string connectionString = "Server = " + server + ";Port = " + port + "; Database = " +
                database + "; Uid = " + username + "; Pwd = " + password + ";";

            connection = new MySqlConnection(connectionString);
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }

        }

        public string StatusConnection()
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                else
                {
                    connection.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return connection.State.ToString();
        }

        public bool InsertDestino(string codIATA, string cidade)
        {
            string query = "insert into Destinos (c_IATA, nome_Cidade) values ('" + codIATA + "', '" + cidade + "');";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool UpdateDestino(string codIATA, string cidade)
        {
            string query = "update Destinos set nome_Cidade = '" + cidade + "' where c_IATA = '" + codIATA + "';";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // Verificar se código IATA já existe
        public int ContarDestino(string codIATA)
        {
            string query = "select count(*) from Destinos where c_IATA = '" + codIATA + "';";

            int count = 0;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    count = int.Parse(cmd.ExecuteScalar().ToString());
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return count;
        }

        public bool PesquisarDestino(string c_IATA, ref string nome_Cidade)

        {
            bool flag = false;

            string query = "select nome_Cidade from Destinos where c_IATA = '" + c_IATA + "';";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    if (cmd.ExecuteScalar() != null) // se a query tem um valor diferente de null a flag fica true
                    {
                        nome_Cidade = cmd.ExecuteScalar().ToString();
                        flag = true;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public void PreencherDataGridViewDestinos(ref DataGridView dgv)
        {

            string query = "select c_IATA, nome_Cidade from Destinos order by nome_Cidade;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["c_IATA"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells[1].Value = dr[1].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public bool InsertAeronave(string matricula, string marcaModelo, string lotacao, string autonomia)
        {
            string query = "insert into Aeronaves (matricula, marcaModelo, lotacao, autonomia) " +
                "values ('" + matricula + "', '" + marcaModelo + "', '" + lotacao + "', '" + autonomia + "');";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool UpdateAeronave(string matricula, string marcaModelo, string lotacao, string autonomia)
        {
            string query = "update Aeronaves set marcaModelo = '" + marcaModelo + "', lotacao = '" + lotacao + "', autonomia = '" + autonomia + "'" +
                " where matricula = '" + matricula + "';";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // Verificar se matrícula já existe
        public int ContarMatricula(string matricula)
        {
            string query = "select count(*) from Aeronaves where matricula = '" + matricula + "';";

            int count = 0;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    count = int.Parse(cmd.ExecuteScalar().ToString());
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return count;
        }

        // método para botão pesquisar
        public bool PesquisarMatricula(string matricula, ref string marcaModelo, ref string lotacao, ref string autonomia)

        {
            bool flag = false;

            string query = "select marcaModelo, lotacao, autonomia from Aeronaves where matricula = '" + matricula + "';";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        marcaModelo = dataReader[0].ToString();
                        lotacao = dataReader["lotacao"].ToString();
                        autonomia = dataReader[2].ToString();
                        flag = true;
                    }
                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public void PreencherDataGridViewAeronaves(ref DataGridView dgv)
        {

            string query = "select matricula, marcaModelo, lotacao, autonomia from Aeronaves order by matricula;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["matricula"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells[1].Value = dr[1].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        dgv.Rows[idxLinha].Cells[2].Value = dr[2].ToString();
                        dgv.Rows[idxLinha].Cells[3].Value = dr[3].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public bool InsertRota(string idRota, string aeropPartida, string aeropChegada, string distancia, string tarifa_OW, string tarifa_RT)
        {
            string query = "insert into Rotas (id_Rota, aeropPartida, aeropChegada, distancia, tarifa_OW, tarifa_RT) " +
                "values ('" + idRota + "', '" + aeropPartida + "', '" + aeropChegada + "', '" + distancia + "', '" + tarifa_OW + "', '" + tarifa_RT + "');";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool UpdateRota(string idRota, string aeropPartida, string aeropChegada, string distancia, string tarifa_OW, string tarifa_RT)
        {
            string query = "update Rotas set aeropPartida = '" + aeropPartida + "', aeropChegada = '" + aeropChegada + "', distancia = '" + distancia + "'" +
                ", tarifa_OW = '" + tarifa_OW + "', tarifa_RT = '" + tarifa_RT + "' where id_Rota = '" + idRota + "';";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // Verificar se id rota já existe
        public int ContarRota(string idRota)
        {
            string query = "select count(*) from Rotas where id_Rota = '" + idRota + "';";

            int count = 0;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    count = int.Parse(cmd.ExecuteScalar().ToString());
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return count;
        }

        // Verificar se id rota já existe usando outro método (alternativa)
        public bool ValidateRota(string idRota)
        {
            bool flag = false;

            try
            {
                string query = "select id_Rota from Rotas where id_Rota = '" + idRota + "';";

                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    if (cmd.ExecuteScalar() != null) // se a query tem um valor diferente de null a flag fica true
                    {
                        idRota = cmd.ExecuteScalar().ToString();
                        flag = true;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // Verificar se rota já existe mesmo com id diferente do que se pretende atribuir
        public bool CheckPercurso(string origem, string destino)
        {
            bool flag = false;

            try
            {
                string query = "select id_Rota from Rotas where aeropPartida = '" + origem + "' and aeropChegada = '" + destino + "';";

                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    if (cmd.ExecuteScalar() != null) //  se a query tem um valor diferente de null a flag fica true
                    {
                        string idRota = cmd.ExecuteScalar().ToString();
                        flag = true;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                //MessageBox.Show("Percurso já existe!");
            }
            finally
            {
                CloseConnection();
            }

            return flag;

        }

        public bool PesquisarIdRota(string idRota, ref string aeropPartida, ref string cIataPartida, ref string aeropChegada,
            ref string cIataChegada, ref string distancia, ref string tarifa_OW, ref string tarifa_RT)

        {
            bool flag = false;

            string query = "select R.aeropPartida, D1.c_IATA, R.aeropChegada, D2.c_IATA, R.distancia, R.tarifa_OW, R.tarifa_RT from Rotas R " +
                "left join Destinos D1 on R.aeropPartida = D1.nome_Cidade left join Destinos D2 on R.aeropChegada = D2.nome_Cidade " +
                "where id_Rota = '" + idRota + "';";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        aeropPartida = dataReader[0].ToString();
                        cIataPartida = dataReader[1].ToString();
                        aeropChegada = dataReader[2].ToString();
                        cIataChegada = dataReader[3].ToString();
                        distancia = dataReader["distancia"].ToString();
                        tarifa_OW = dataReader["tarifa_OW"].ToString();
                        tarifa_RT = dataReader["tarifa_RT"].ToString();
                        flag = true;
                    }
                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public void PreencherComboAerop(ref ComboBox cmb)
        {
            //cmb.Items.Clear(); // apaga os itens após cada operação com a combobox - foi colocado nos forms respetivos em vez de se pôr neste método

            string query = "select c_IATA, nome_Cidade from Destinos order by nome_Cidade;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensDestinos = dr[1].ToString() + " - " + dr[0].ToString();
                        cmb.Items.Add(itensDestinos);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboTarifa(ref ComboBox cmb, string tipo)
        {
            string query = "select id_Tarifa from Tarifas where tipo = '" + tipo + "';";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensTipo = dr[0].ToString();
                        cmb.Items.Add(itensTipo);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherDataGridViewRotas(ref DataGridView dgv)
        {

            string query = "select id_Rota, aeropPartida, aeropChegada, distancia, tarifa_OW, tarifa_RT from Rotas order by id_Rota;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["id_Rota"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells[1].Value = dr[1].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        dgv.Rows[idxLinha].Cells[2].Value = dr[2].ToString();
                        dgv.Rows[idxLinha].Cells[3].Value = dr[3].ToString();
                        dgv.Rows[idxLinha].Cells["tarifa_OW"].Value = dr[4].ToString();
                        dgv.Rows[idxLinha].Cells["tarifa_RT"].Value = dr[5].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

        }

        public bool InsertTarifa(string idTarifa, string descricaoTarifa, string valorKm, string tipo)
        {
            string query = "insert into Tarifas (id_Tarifa, descricaoTarifa, valorTarifa, tipo) " +
                "values ('" + idTarifa + "', '" + descricaoTarifa + "', '" + valorKm + "', '" + tipo + "');";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool UpdateTarifa(string idTarifa, string descricaoTarifa, string valorKm, string tipo)
        {
            string query = "update Tarifas set descricaoTarifa = '" + descricaoTarifa + "', valorTarifa = '" + valorKm + "', tipo = '" + tipo + "'" +
                " where id_Tarifa = '" + idTarifa + "';";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // método para botão pesquisar
        public bool PesquisarTarifa(string idTarifa, ref string descricaoTarifa, ref string valorKm, ref string tipo)

        {
            bool flag = false;

            string query = "select descricaoTarifa, valorTarifa, tipo from Tarifas where id_Tarifa = '" + idTarifa + "';";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        descricaoTarifa = dataReader[0].ToString();
                        valorKm = dataReader["valorTarifa"].ToString();
                        tipo = dataReader[2].ToString();
                        flag = true;
                    }
                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool ValidateTarifa(string idTarifa)
        {
            bool flag = false;

            try
            {
                string query = "select id_Tarifa from Tarifas where id_Tarifa = '" + idTarifa + "';";

                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    if (cmd.ExecuteScalar() != null) // se a query tem um valor diferente de null a flag fica true
                    {
                        //idTarifa = cmd.ExecuteScalar().ToString();
                        flag = true;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public void PreencherDataGridViewTarifas(ref DataGridView dgv)
        {

            string query = "select id_Tarifa, descricaoTarifa, valorTarifa, tipo from Tarifas order by id_Tarifa;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["id_Tarifa"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells[1].Value = dr[1].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        dgv.Rows[idxLinha].Cells[2].Value = dr[2].ToString();
                        dgv.Rows[idxLinha].Cells[3].Value = dr[3].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public bool InsertVoos(string idRota, string matricula, string dataVoo, string horaPartida, string horaChegada, char estado, string numLugares)
        {
            string query = "insert into Voos (id_Voo, id_Rota, matricula, dataVoo, horaPartida, horaChegada, estado, numLugares) " +
                "values (0, '" + idRota + "'";

            // tratar situações em que a matrícula é = null
            if (matricula == "" || matricula == null)
            {
                matricula = "NULL";
                query = query + ", " + matricula;
            }
            else
            {
                query = query + ", '" + matricula + "'";
            }

            query = query + ", '" + dataVoo + "', '" + horaPartida + "', '" + horaChegada + "', '" + estado + "', '" + numLugares + "');";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool UpdateVoos(string id_Voo, string idRota, string matricula, string dataVoo, string horaPartida, string horaChegada,
            char estado, string numLugares)
        {
            string query = "update Voos set id_Rota = '" + idRota + "'";

            // tratar situações em que a matrícula é = null
            if (matricula == "" || matricula == null)
            {
                matricula = "NULL";
                query = query + ", matricula = " + matricula;
            }
            else
            {
                query = query + ", matricula = '" + matricula + "'";
            }

            query = query + ", dataVoo = '" + dataVoo + "'" + ", horaPartida = '" + horaPartida + "', horaChegada = '" + horaChegada +
                "', estado = '" + estado + "', numLugares = '" + numLugares + "' where id_Voo = '" + id_Voo + "';";

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // Verificar se id voo já existe
        public bool ValidateVoo(string idVoo)
        {
            bool flag = false;

            try
            {
                string query = "select id_Voo from Voos where id_Voo = '" + idVoo + "';";

                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    if (cmd.ExecuteScalar() != null) // se a query tem um valor diferente de null a flag fica true
                    {
                        // idVoo = cmd.ExecuteScalar().ToString();
                        flag = true;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool ValidateVoo(string idRota, string dataVoo)
        {
            bool flag = false;

            try
            {
                // O uso de @ permite usar parâmetros na query SQL (queries parametrizadas) prevenindo ataques de SQL Injection
                string query = "select id_Rota, dataVoo from Voos where id_Rota = '" + @idRota + "' and dataVoo = '" + @dataVoo + "';";

                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@idRota", idRota);
                    cmd.Parameters.AddWithValue("@dataVoo", dataVoo);

                    MySqlDataReader dataReader = cmd.ExecuteReader();

                    flag = dataReader.HasRows; // Verifica apenas se a query não é vazia

                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool PesquisarIdVoo(string idVoo, ref string idRota, ref string matricula, ref string dataVoo,
            ref string horaPartida, ref string horaChegada, ref char estado, ref string numLugares)

        {
            bool flag = false;

            string query = "select id_Rota, matricula, dataVoo, horaPartida, horaChegada, estado, numLugares from Voos" +
                " where id_Voo = '" + idVoo + "';";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        idRota = dataReader["id_Rota"].ToString();
                        matricula = dataReader["matricula"].ToString();
                        dataVoo = dataReader["dataVoo"].ToString();
                        horaPartida = dataReader["horaPartida"].ToString();
                        horaChegada = dataReader["horaChegada"].ToString();
                        estado = dataReader["estado"].ToString()[0];
                        numLugares = dataReader["numLugares"].ToString();
                        flag = true;
                    }
                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public void PreencherComboIdRota(ref ComboBox cmb)
        {
            //cmb.Items.Clear(); // apaga os itens após cada operação com a combobox - foi colocado nos forms respetivos em vez de se pôr neste método

            string query = "select id_Rota, aeropPartida, aeropChegada from Rotas order by id_Rota;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensDestinos = dr[0].ToString() + " - " + dr[1].ToString() + " - " + dr[2].ToString();
                        cmb.Items.Add(itensDestinos);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboMatricula(ref ComboBox cmb)
        {
            string query = "select matricula from Aeronaves;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensTipo = dr[0].ToString();
                        cmb.Items.Add(itensTipo);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public int DevolveUltimoIdVoo()
        {
            int ultimoIdVoo = 0;

            string query = "select max(id_Voo) from Voos";
            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    //ultimoID = int.Parse(cmd.ExecuteScalar().ToString());
                    //se o TryParse não conseguir converter para int atribui valor zero à variável
                    int.TryParse(cmd.ExecuteScalar().ToString(), out ultimoIdVoo);
                    ultimoIdVoo++;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //catch
            //{
            //    Message.Show("ERRO!");
            //}
            finally
            {
                CloseConnection();
            }

            return ultimoIdVoo;
        }


        //Usado para preencher DataGridView sem filtros e pelo botão refresh
        public void PreencherDataGridViewVoos(ref DataGridView dgv)
        {
            string query = "select V.id_Voo, V.matricula, R.aeropPartida, R.aeropChegada, V.dataVoo, V.horaPartida, V.horaChegada," +
                " V.estado, V.numLugares, count(Vd.id_Voo) as numPax from Voos V left join Rotas R on V.id_Rota = R.id_Rota" +
                " left join Vendas Vd on V.id_Voo = Vd.id_Voo where V.dataVoo between date_sub(curdate(), interval 30 day)" +
                " and date_add(curdate(), interval 30 day)" +
                " group by V.id_Voo;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["ID Voo"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells["matricula"].Value = dr[1].ToString();
                        dgv.Rows[idxLinha].Cells["aeropPartida"].Value = dr[2].ToString();
                        dgv.Rows[idxLinha].Cells[3].Value = dr[3].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        DateTime dataVoo = DateTime.Parse(dr["dataVoo"].ToString()); //Conversão de string para data e depois para o formato dd-MM-yyyy
                        dgv.Rows[idxLinha].Cells[4].Value = dataVoo.ToString("dd-MM-yyyy");
                        DateTime horaPartida = DateTime.Parse(dr["horaPartida"].ToString());
                        dgv.Rows[idxLinha].Cells[5].Value = horaPartida.ToString("HH:mm");
                        DateTime horaChegada = DateTime.Parse(dr["horaChegada"].ToString());
                        dgv.Rows[idxLinha].Cells[6].Value = horaChegada.ToString("HH:mm");
                        dgv.Rows[idxLinha].Cells["Estado"].Value = dr["estado"].ToString();
                        dgv.Rows[idxLinha].Cells["Nº Lugares"].Value = dr["numLugares"].ToString();
                        dgv.Rows[idxLinha].Cells["Nº Pax"].Value = dr["numPax"].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        //Usado para os filtros do DataGridView (botão pesquisa)
        public void PreencherDataGridViewVoos(ref DataGridView dgv, string matricula, string dataInicio, string dataFim, char estado,
            string aeropPartida, string aeropChegada)
        {
            string query = "select V.id_Voo, V.matricula, R.aeropPartida, R.aeropChegada, V.dataVoo, V.horaPartida, V.horaChegada," +
                " V.estado, V.numLugares, count(Vd.id_Voo) as numPax from Voos V left join Rotas R on V.id_Rota = R.id_Rota" +
                " left join Vendas Vd on V.id_Voo = Vd.id_Voo where V.dataVoo between '" + dataInicio + "' and '" + dataFim + "'";

            if (matricula.Length > 0)
            {
                query = query + " and matricula = '" + matricula + "'";
            }

            if (estado != 'T')
            {
                query = query + " and estado = '" + estado + "'";
            }

            if (aeropPartida.Length > 0)
            {
                query = query + " and aeropPartida = '" + aeropPartida + "' and aeropChegada = '" + aeropChegada + "'";
            }

            query = query + " group by V.id_Voo;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["ID Voo"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells["matricula"].Value = dr[1].ToString();
                        dgv.Rows[idxLinha].Cells["aeropPartida"].Value = dr[2].ToString();
                        dgv.Rows[idxLinha].Cells[3].Value = dr[3].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        DateTime dataVoo = DateTime.Parse(dr["dataVoo"].ToString()); //Conversão de string para data e depois para o formato dd-MM-yyyy
                        dgv.Rows[idxLinha].Cells[4].Value = dataVoo.ToString("dd-MM-yyyy");
                        DateTime horaPartida = DateTime.Parse(dr["horaPartida"].ToString());
                        dgv.Rows[idxLinha].Cells[5].Value = horaPartida.ToString("HH:mm");
                        DateTime horaChegada = DateTime.Parse(dr["horaChegada"].ToString());
                        dgv.Rows[idxLinha].Cells[6].Value = horaChegada.ToString("HH:mm");
                        dgv.Rows[idxLinha].Cells["Estado"].Value = dr["estado"].ToString();
                        dgv.Rows[idxLinha].Cells["Nº Lugares"].Value = dr["numLugares"].ToString();
                        dgv.Rows[idxLinha].Cells["Nº Pax"].Value = dr["numPax"].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboOrigem(ref ComboBox cmb)
        {
            string query = "select nome_Cidade from Destinos order by nome_Cidade;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensDestinos = dr[0].ToString();
                        cmb.Items.Add(itensDestinos);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboDestino(ref ComboBox cmb, string origem)
        {
            string query = "select distinct aeropChegada from Rotas where aeropPartida = '" + origem + "' order by aeropChegada;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensDestinos = dr[0].ToString();
                        cmb.Items.Add(itensDestinos);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboDataIda(ref ComboBox cmb, string aeropPartida, string aeropChegada)
        {
            string query = "select V.dataVoo from Voos V join Rotas R on V.id_Rota = R.id_Rota" +
                " left join Vendas Vd on V.id_Voo = Vd.id_Voo where R.aeropPartida = '" + aeropPartida + "'and" +
                " R.aeropChegada = '" + aeropChegada + "' and V.dataVoo > curdate()" +
                " group by V.dataVoo, V.numLugares" +
                " having count(Vd.id_Voo) < V.numLugares or count(Vd.id_Voo) is null" +
                " order by V.dataVoo;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itens = dr[0].ToString();
                        DateTime dataVoo = DateTime.Parse(itens.ToString());
                        cmb.Items.Add(dataVoo.ToString("dd-MM-yyyy"));
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboDataVolta(ref ComboBox cmb, string aeropPartida, string aeropChegada, string dataIda)
        {
            string query = "select V.dataVoo from Voos V join Rotas R on V.id_Rota = R.id_Rota" +
                " left join Vendas Vd on V.id_Voo = Vd.id_Voo where R.aeropPartida = '" + aeropPartida + "'and" +
                " R.aeropChegada = '" + aeropChegada + "' and V.dataVoo > '" + dataIda + "'" +
                " group by V.dataVoo, V.numLugares" +
                " having count(Vd.id_Voo) < V.numLugares or count(Vd.id_Voo) is null" +
                " order by V.dataVoo;";
            
            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itens = dr[0].ToString();
                        DateTime dataVoo = DateTime.Parse(itens.ToString());
                        cmb.Items.Add(dataVoo.ToString("dd-MM-yyyy"));
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherDataGridViewItinerario(ref DataGridView dgv, string origem, string destino, string dataIda, string dataVolta,
            char tipoPercurso)
        {
            string query = "select V.id_Voo, R.aeropPartida, R.aeropChegada, V.dataVoo, V.horaPartida, V.horaChegada";

            if (tipoPercurso == 'I')
            {
                query = query + ", R.tarifa_OW, T.valorTarifa * R.distancia as Subtotal" +
                    " from Voos V left join Rotas R on V.id_Rota = R.id_Rota left join Tarifas T on R.tarifa_OW = T.id_Tarifa" +
                    " where V.estado = 'P' and ((V.dataVoo = '" + dataIda + "'" +
                    " and R.aeropPartida = '" + origem + "' and R.aeropChegada = '" + destino + "')";
            }
                

            if (tipoPercurso == 'V')
            {
                query = query + ", R.tarifa_RT, T.valorTarifa * R.distancia as Subtotal" +
                    " from Voos V left join Rotas R on V.id_Rota = R.id_Rota left join Tarifas T on R.tarifa_RT = T.id_Tarifa" +
                    " where V.estado = 'P' and ((V.dataVoo = '" + dataIda + "'" +
                    " and R.aeropPartida = '" + origem + "' and R.aeropChegada = '" + destino + "')" + 
                    " or (V.dataVoo = '" + dataVolta + "' and R.aeropPartida = '" + destino + "' and R.aeropChegada = '" + origem + "')";
            }            

            query = query + ") order by V.dataVoo;";            

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["ID Voo"].Value = dr[0].ToString();                        
                        dgv.Rows[idxLinha].Cells["aeropPartida"].Value = dr[1].ToString();
                        dgv.Rows[idxLinha].Cells[2].Value = dr[2].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        DateTime dataVoo = DateTime.Parse(dr["dataVoo"].ToString()); //Conversão de string para data e depois para o formato dd-MM-yyyy
                        dgv.Rows[idxLinha].Cells[3].Value = dataVoo.ToString("dd-MM-yyyy");
                        DateTime horaPartida = DateTime.Parse(dr["horaPartida"].ToString());
                        dgv.Rows[idxLinha].Cells[4].Value = horaPartida.ToString("HH:mm");
                        DateTime horaChegada = DateTime.Parse(dr["horaChegada"].ToString());
                        dgv.Rows[idxLinha].Cells[5].Value = horaChegada.ToString("HH:mm");
                        dgv.Rows[idxLinha].Cells["tarifa"].Value = dr[6].ToString();
                        dgv.Rows[idxLinha].Cells["Subtotal"].Value = dr[7].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public bool InsertPax(string idPax, string nome, string pais, string titulo, string dataNascimento, string email)
        {
            // insert ignore vai ignorar a query se o id_Pax (PK) já existir
            string query = "insert ignore into passageiros (id_Pax, nome, pais, titulo, dataNascimento, email) " +
                "values ('" + idPax + "', '" + nome + "', '" + pais + "', '" + titulo + "', '" + dataNascimento + "', '" + email + "');";            

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool InsertVendas(string dataTkt, string idPax, string idTarifa, string idVoo)
        {
            string query = "insert into Vendas (tkt, dataTkt, id_Pax, id_Tarifa, id_Voo) " +
                "values (0, '" + dataTkt + "', '" + idPax + "', '" + idTarifa + "', '" + idVoo + "');";            

            bool flag = true;

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(@query, connection);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                flag = false;
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public void PreencherComboPais(ref ComboBox cmb)
        {
            string query = "select alpha2, pais from Paises order by pais;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensDestinos = dr[0].ToString() + " - " + dr[1].ToString();
                        cmb.Items.Add(itensDestinos);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public int DevolveNumeroBilhete()
        {
            int ultimoTkt = 0;

            string query = "select max(tkt) from Vendas";
            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    //ultimoID = int.Parse(cmd.ExecuteScalar().ToString());
                    //se o TryParse não conseguir converter para int atribui valor zero à variável
                    int.TryParse(cmd.ExecuteScalar().ToString(), out ultimoTkt);
                    //ultimoTkt++;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }            
            finally
            {
                CloseConnection();
            }

            return ultimoTkt;
        }

        public bool PesquisarBilhete(string numBilhete, ref string origem, ref string destino, ref string tipoPercurso, ref string dataIda,
            ref string nome, ref string docId, ref string titulo, ref string pais, ref string dataNascimento, ref string email)

        {
            bool flag = false;

            string query = "select Vd.tkt, R.aeropPartida, R.aeropChegada, T.tipo, V1.dataVoo, P.nome, Vd.id_Pax, P.titulo, P.pais," +
                " P.dataNascimento, P.email" +
                " from Vendas Vd" +
                " left join Tarifas T on Vd.id_Tarifa = T.id_Tarifa" +
                " left join Voos V1 on Vd.id_Voo = V1.id_Voo" +
                " left join Rotas R on V1.id_Rota = R.id_Rota" +
                " left join Passageiros P on Vd.id_Pax = P.id_Pax" +
                " where (Vd.dataTkt, Vd.id_Pax) in (select Vd.dataTkt, Vd.id_Pax from Vendas Vd where Vd.tkt = '" + numBilhete + "')" +
                " order by Vd.tkt" +
                " limit 1;";            

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {
                        origem = dataReader["aeropPartida"].ToString();
                        destino = dataReader["aeropChegada"].ToString();
                        tipoPercurso = dataReader["tipo"].ToString();                        
                        DateTime dataVoo = DateTime.Parse(dataReader["dataVoo"].ToString());
                        dataIda = dataVoo.ToString("dd-MM-yyyy");                        
                        nome = dataReader["nome"].ToString();
                        docId = dataReader["id_Pax"].ToString();
                        titulo = dataReader["titulo"].ToString();
                        pais = dataReader["pais"].ToString();
                        dataNascimento = dataReader["dataNascimento"].ToString();
                        email = dataReader["email"].ToString();
                        flag = true;
                    }
                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        public bool PesquisarBilheteDataVolta(string numBilhete, ref string dataVolta)

        {
            bool flag = false;

            string query = "select V.dataVoo from Voos V" +
                " right join Vendas Vd on Vd.id_Voo = V.id_Voo" +
                " where (Vd.dataTkt, Vd.id_Pax) in (select Vd.dataTkt, Vd.id_Pax from Vendas Vd where Vd.tkt = '" + numBilhete + "')" +
                " order by Vd.tkt desc" +
                " limit 1;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();
                    while (dataReader.Read())
                    {                        
                        DateTime dataVoo = DateTime.Parse(dataReader["dataVoo"].ToString());
                        dataVolta = dataVoo.ToString("dd-MM-yyyy");
                        flag = true;
                    }
                    dataReader.Close();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }

            return flag;
        }

        // DataGridView do itinerário despois da emissão do bilhete (nº bilhete já existe)
        public void PreencherDataGridViewItinerario(ref DataGridView dgv, string origem, string destino, string dataIda,
            string dataVolta, string tipoPercurso, string idPax)
        {
            string query = "select Vd.id_Voo, R.aeropPartida, R.aeropChegada, V.dataVoo, V.horaPartida, V.horaChegada," +
                " Vd.id_Tarifa, Vd.receita" +
                " from Vendas Vd" +
                " left join Voos V on Vd.id_Voo = V.id_Voo" +
                " left join Rotas R on V.id_Rota = R.id_Rota" +
                " left join Tarifas T on Vd.id_Tarifa = T.id_Tarifa";

            if (tipoPercurso == "OW")
            {
                query = query + " where T.tipo = 'OW' and Vd.id_Pax = '" + idPax + "' and ((V.dataVoo = '" + dataIda + "'" +
                    " and R.aeropPartida = '" + origem + "' and R.aeropChegada = '" + destino + "')";
            }


            if (tipoPercurso == "RT")
            {
                query = query + " where T.tipo = 'RT' and Vd.id_Pax = '" + idPax + "' and ((V.dataVoo = '" + dataIda + "'" +
                    " and R.aeropPartida = '" + origem + "' and R.aeropChegada = '" + destino + "')" +
                    " or (V.dataVoo = '" + dataVolta + "' and R.aeropPartida = '" + destino + "' and R.aeropChegada = '" + origem + "')";
            }

            query = query + ") order by V.dataVoo;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["ID Voo"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells["aeropPartida"].Value = dr[1].ToString();
                        dgv.Rows[idxLinha].Cells[2].Value = dr[2].ToString(); // Pode-se chamar pelo nome ou pelo índice
                        DateTime dataVoo = DateTime.Parse(dr["dataVoo"].ToString()); //Conversão de string para data e depois para o formato dd-MM-yyyy
                        dgv.Rows[idxLinha].Cells[3].Value = dataVoo.ToString("dd-MM-yyyy");
                        DateTime horaPartida = DateTime.Parse(dr["horaPartida"].ToString());
                        dgv.Rows[idxLinha].Cells[4].Value = horaPartida.ToString("HH:mm");
                        DateTime horaChegada = DateTime.Parse(dr["horaChegada"].ToString());
                        dgv.Rows[idxLinha].Cells[5].Value = horaChegada.ToString("HH:mm");
                        dgv.Rows[idxLinha].Cells["tarifa"].Value = dr[6].ToString();
                        dgv.Rows[idxLinha].Cells["Subtotal"].Value = dr[7].ToString();
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherDataGridViewListaPassageiros(ref DataGridView dgv, string idVoo)
        {
            string query = "select V.id_Voo, P.id_Pax, P.nome, P.titulo, P.Pais, R.aeropPartida, R.aeropChegada," +
                " V.dataVoo, V.estado from Voos V" +
                " left join Rotas R on V.id_Rota = R.id_Rota" +
                " left join Vendas Vd on V.id_Voo = Vd.id_Voo" +
                " left join Passageiros P on P.id_Pax = Vd.id_Pax" +
                " where V.id_Voo = '" + idVoo + "'" +
                " group by V.id_Voo, P.id_Pax, P.nome, P.titulo, P.Pais, R.aeropPartida, R.aeropChegada, V.dataVoo, V.estado" +
                " having count(P.id_Pax) > 0;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["ID Voo"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells["idPax"].Value = dr[1].ToString();
                        dgv.Rows[idxLinha].Cells["Nome"].Value = dr[2].ToString();
                        dgv.Rows[idxLinha].Cells["Titulo"].Value = dr[3].ToString();
                        dgv.Rows[idxLinha].Cells["Pais"].Value = dr[4].ToString();
                        dgv.Rows[idxLinha].Cells["Origem"].Value = dr[5].ToString();
                        dgv.Rows[idxLinha].Cells["Destino"].Value = dr[6].ToString();                        
                        DateTime dataVoo = DateTime.Parse(dr["dataVoo"].ToString()); //Conversão de string para data e depois para o formato dd-MM-yyyy
                        dgv.Rows[idxLinha].Cells[7].Value = dataVoo.ToString("dd-MM-yyyy");                        
                        dgv.Rows[idxLinha].Cells["Estado"].Value = dr["estado"].ToString();                        
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherComboIdVoo(ref ComboBox cmb)
        {
            string query = "select id_Voo from Voos order by id_Voo;";

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string itensDestinos = dr[0].ToString();
                        cmb.Items.Add(itensDestinos);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public void PreencherDataGridViewVendas(ref DataGridView dgv, string idVoo)
        {
            string query = "select id_Voo, id_Pax, tkt, dataTkt, id_Tarifa, receita" +
                " from Vendas" +
                " where id_Voo = '" + idVoo + "';";               

            try
            {
                if (OpenConnection())
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dr = cmd.ExecuteReader();

                    int idxLinha = 0;
                    while (dr.Read())
                    {
                        dgv.Rows.Add();
                        dgv.Rows[idxLinha].Cells["ID Voo"].Value = dr[0].ToString();
                        dgv.Rows[idxLinha].Cells["idPax"].Value = dr[1].ToString();
                        dgv.Rows[idxLinha].Cells["NumBilhete"].Value = dr[2].ToString();
                        DateTime dataTkt = DateTime.Parse(dr["dataTkt"].ToString()); //Conversão de string para data e depois para o formato dd-MM-yyyy
                        dgv.Rows[idxLinha].Cells[3].Value = dataTkt.ToString("dd-MM-yyyy");
                        dgv.Rows[idxLinha].Cells["Tarifa"].Value = dr[4].ToString();
                        dgv.Rows[idxLinha].Cells["Receita"].Value = dr[5].ToString();                        
                        idxLinha++;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                CloseConnection();
            }
        }
    }
}
