﻿namespace ReservaVoos
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.reservaDeVoosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reservaDeVooToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.listarAsNossasRotasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áreaReservadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.voosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aeronavesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.destinosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rotasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tarifasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vendasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarVoosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarAeronavesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarDestinosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarTarifasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listaPassageirosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reservaDeVoosToolStripMenuItem,
            this.áreaReservadaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(676, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // reservaDeVoosToolStripMenuItem
            // 
            this.reservaDeVoosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reservaDeVooToolStripMenuItem,
            this.toolStripMenuItem1,
            this.listarAsNossasRotasToolStripMenuItem});
            this.reservaDeVoosToolStripMenuItem.Name = "reservaDeVoosToolStripMenuItem";
            this.reservaDeVoosToolStripMenuItem.Size = new System.Drawing.Size(61, 24);
            this.reservaDeVoosToolStripMenuItem.Text = "&Viajar";
            // 
            // reservaDeVooToolStripMenuItem
            // 
            this.reservaDeVooToolStripMenuItem.Name = "reservaDeVooToolStripMenuItem";
            this.reservaDeVooToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.reservaDeVooToolStripMenuItem.Text = "&Reserva de voo";
            this.reservaDeVooToolStripMenuItem.Click += new System.EventHandler(this.reservaDeVooToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(221, 6);
            // 
            // listarAsNossasRotasToolStripMenuItem
            // 
            this.listarAsNossasRotasToolStripMenuItem.Name = "listarAsNossasRotasToolStripMenuItem";
            this.listarAsNossasRotasToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.listarAsNossasRotasToolStripMenuItem.Text = "&As Nossas Rotas";
            this.listarAsNossasRotasToolStripMenuItem.Click += new System.EventHandler(this.listarAsNossasRotasToolStripMenuItem_Click);
            // 
            // áreaReservadaToolStripMenuItem
            // 
            this.áreaReservadaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.operaçõesToolStripMenuItem,
            this.relatóriosToolStripMenuItem1});
            this.áreaReservadaToolStripMenuItem.Name = "áreaReservadaToolStripMenuItem";
            this.áreaReservadaToolStripMenuItem.Size = new System.Drawing.Size(126, 24);
            this.áreaReservadaToolStripMenuItem.Text = "Área &Reservada";
            // 
            // operaçõesToolStripMenuItem
            // 
            this.operaçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.voosToolStripMenuItem,
            this.aeronavesToolStripMenuItem,
            this.destinosToolStripMenuItem1,
            this.rotasToolStripMenuItem,
            this.tarifasToolStripMenuItem});
            this.operaçõesToolStripMenuItem.Name = "operaçõesToolStripMenuItem";
            this.operaçõesToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.operaçõesToolStripMenuItem.Text = "&Operações";
            // 
            // voosToolStripMenuItem
            // 
            this.voosToolStripMenuItem.Name = "voosToolStripMenuItem";
            this.voosToolStripMenuItem.Size = new System.Drawing.Size(236, 26);
            this.voosToolStripMenuItem.Text = "&Planeamento de Voos";
            this.voosToolStripMenuItem.Click += new System.EventHandler(this.voosToolStripMenuItem_Click);
            // 
            // aeronavesToolStripMenuItem
            // 
            this.aeronavesToolStripMenuItem.Name = "aeronavesToolStripMenuItem";
            this.aeronavesToolStripMenuItem.Size = new System.Drawing.Size(236, 26);
            this.aeronavesToolStripMenuItem.Text = "&Aeronaves";
            this.aeronavesToolStripMenuItem.Click += new System.EventHandler(this.aeronavesToolStripMenuItem_Click);
            // 
            // destinosToolStripMenuItem1
            // 
            this.destinosToolStripMenuItem1.Name = "destinosToolStripMenuItem1";
            this.destinosToolStripMenuItem1.Size = new System.Drawing.Size(236, 26);
            this.destinosToolStripMenuItem1.Text = "&Destinos";
            this.destinosToolStripMenuItem1.Click += new System.EventHandler(this.destinosToolStripMenuItem1_Click);
            // 
            // rotasToolStripMenuItem
            // 
            this.rotasToolStripMenuItem.Name = "rotasToolStripMenuItem";
            this.rotasToolStripMenuItem.Size = new System.Drawing.Size(236, 26);
            this.rotasToolStripMenuItem.Text = "&Rotas";
            this.rotasToolStripMenuItem.Click += new System.EventHandler(this.rotasToolStripMenuItem_Click);
            // 
            // tarifasToolStripMenuItem
            // 
            this.tarifasToolStripMenuItem.Name = "tarifasToolStripMenuItem";
            this.tarifasToolStripMenuItem.Size = new System.Drawing.Size(236, 26);
            this.tarifasToolStripMenuItem.Text = "&Tarifas";
            this.tarifasToolStripMenuItem.Click += new System.EventHandler(this.tarifasToolStripMenuItem_Click);
            // 
            // relatóriosToolStripMenuItem1
            // 
            this.relatóriosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vendasToolStripMenuItem,
            this.listarVoosToolStripMenuItem,
            this.listarAeronavesToolStripMenuItem,
            this.listarDestinosToolStripMenuItem,
            this.listarTarifasToolStripMenuItem,
            this.listaPassageirosToolStripMenuItem});
            this.relatóriosToolStripMenuItem1.Name = "relatóriosToolStripMenuItem1";
            this.relatóriosToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.relatóriosToolStripMenuItem1.Text = "&Relatórios";
            // 
            // vendasToolStripMenuItem
            // 
            this.vendasToolStripMenuItem.Name = "vendasToolStripMenuItem";
            this.vendasToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.vendasToolStripMenuItem.Text = "&Vendas";
            this.vendasToolStripMenuItem.Click += new System.EventHandler(this.vendasToolStripMenuItem_Click);
            // 
            // listarVoosToolStripMenuItem
            // 
            this.listarVoosToolStripMenuItem.Name = "listarVoosToolStripMenuItem";
            this.listarVoosToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.listarVoosToolStripMenuItem.Text = "&Listar Voos";
            this.listarVoosToolStripMenuItem.Click += new System.EventHandler(this.listarVoosToolStripMenuItem_Click);
            // 
            // listarAeronavesToolStripMenuItem
            // 
            this.listarAeronavesToolStripMenuItem.Name = "listarAeronavesToolStripMenuItem";
            this.listarAeronavesToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.listarAeronavesToolStripMenuItem.Text = "Listar &Aeronaves";
            this.listarAeronavesToolStripMenuItem.Click += new System.EventHandler(this.listarAeronavesToolStripMenuItem_Click);
            // 
            // listarDestinosToolStripMenuItem
            // 
            this.listarDestinosToolStripMenuItem.Name = "listarDestinosToolStripMenuItem";
            this.listarDestinosToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.listarDestinosToolStripMenuItem.Text = "Listar &Destinos";
            this.listarDestinosToolStripMenuItem.Click += new System.EventHandler(this.listarDestinosToolStripMenuItem_Click_1);
            // 
            // listarTarifasToolStripMenuItem
            // 
            this.listarTarifasToolStripMenuItem.Name = "listarTarifasToolStripMenuItem";
            this.listarTarifasToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.listarTarifasToolStripMenuItem.Text = "Listar &Tarifas";
            this.listarTarifasToolStripMenuItem.Click += new System.EventHandler(this.listarTarifasToolStripMenuItem_Click);
            // 
            // listaPassageirosToolStripMenuItem
            // 
            this.listaPassageirosToolStripMenuItem.Name = "listaPassageirosToolStripMenuItem";
            this.listaPassageirosToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.listaPassageirosToolStripMenuItem.Text = "Lista &Passageiros";
            this.listaPassageirosToolStripMenuItem.Click += new System.EventHandler(this.listaPassageirosToolStripMenuItem_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(676, 388);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormPrincipal";
            this.Text = "Sistema de Reserva de Voos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem reservaDeVoosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reservaDeVooToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listarAsNossasRotasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áreaReservadaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem voosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aeronavesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rotasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatóriosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tarifasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarVoosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarAeronavesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarDestinosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarTarifasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem destinosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem listaPassageirosToolStripMenuItem;
    }
}