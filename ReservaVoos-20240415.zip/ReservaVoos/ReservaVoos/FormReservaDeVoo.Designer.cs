﻿namespace ReservaVoos
{
    partial class FormReservaDeVoo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormReservaDeVoo));
            this.mtxtDataNascimento = new System.Windows.Forms.MaskedTextBox();
            this.lblDataIda = new System.Windows.Forms.Label();
            this.gbxDados = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbxTitulo = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbxPais = new System.Windows.Forms.ComboBox();
            this.txtDocId = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPesquisarDatas = new System.Windows.Forms.Button();
            this.gbxSelecaoVoos = new System.Windows.Forms.GroupBox();
            this.btnSelecionarVoo = new System.Windows.Forms.Button();
            this.cbxDataVolta = new System.Windows.Forms.ComboBox();
            this.cbxDataIda = new System.Windows.Forms.ComboBox();
            this.lblDataVolta = new System.Windows.Forms.Label();
            this.rbIdaVolta = new System.Windows.Forms.RadioButton();
            this.rbIda = new System.Windows.Forms.RadioButton();
            this.cbxDestino = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbxOrigem = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxItinerario = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.btnPesquisarNumBilhete = new System.Windows.Forms.Button();
            this.lblTotalPagar = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.txtNumBilhete = new System.Windows.Forms.TextBox();
            this.gbxDados.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbxSelecaoVoos.SuspendLayout();
            this.gbxItinerario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // mtxtDataNascimento
            // 
            this.mtxtDataNascimento.Location = new System.Drawing.Point(481, 91);
            this.mtxtDataNascimento.Mask = "00/00/0000";
            this.mtxtDataNascimento.Name = "mtxtDataNascimento";
            this.mtxtDataNascimento.Size = new System.Drawing.Size(95, 22);
            this.mtxtDataNascimento.TabIndex = 9;
            this.mtxtDataNascimento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtxtDataNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // lblDataIda
            // 
            this.lblDataIda.AutoSize = true;
            this.lblDataIda.Location = new System.Drawing.Point(383, 93);
            this.lblDataIda.Name = "lblDataIda";
            this.lblDataIda.Size = new System.Drawing.Size(58, 16);
            this.lblDataIda.TabIndex = 7;
            this.lblDataIda.Text = "Data Ida";
            // 
            // gbxDados
            // 
            this.gbxDados.Controls.Add(this.txtEmail);
            this.gbxDados.Controls.Add(this.label13);
            this.gbxDados.Controls.Add(this.cbxTitulo);
            this.gbxDados.Controls.Add(this.label5);
            this.gbxDados.Controls.Add(this.cbxPais);
            this.gbxDados.Controls.Add(this.txtDocId);
            this.gbxDados.Controls.Add(this.txtNome);
            this.gbxDados.Controls.Add(this.mtxtDataNascimento);
            this.gbxDados.Controls.Add(this.label8);
            this.gbxDados.Controls.Add(this.label7);
            this.gbxDados.Controls.Add(this.label4);
            this.gbxDados.Controls.Add(this.label3);
            this.gbxDados.Location = new System.Drawing.Point(22, 432);
            this.gbxDados.Name = "gbxDados";
            this.gbxDados.Size = new System.Drawing.Size(869, 133);
            this.gbxDados.TabIndex = 3;
            this.gbxDados.TabStop = false;
            this.gbxDados.Text = "Os seus dados";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(722, 91);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(127, 22);
            this.txtEmail.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(657, 94);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "Email";
            // 
            // cbxTitulo
            // 
            this.cbxTitulo.FormattingEnabled = true;
            this.cbxTitulo.Location = new System.Drawing.Point(722, 36);
            this.cbxTitulo.Name = "cbxTitulo";
            this.cbxTitulo.Size = new System.Drawing.Size(60, 24);
            this.cbxTitulo.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(657, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Título";
            // 
            // cbxPais
            // 
            this.cbxPais.FormattingEnabled = true;
            this.cbxPais.Location = new System.Drawing.Point(127, 91);
            this.cbxPais.Name = "cbxPais";
            this.cbxPais.Size = new System.Drawing.Size(152, 24);
            this.cbxPais.TabIndex = 7;
            // 
            // txtDocId
            // 
            this.txtDocId.Location = new System.Drawing.Point(481, 36);
            this.txtDocId.Name = "txtDocId";
            this.txtDocId.Size = new System.Drawing.Size(143, 22);
            this.txtDocId.TabIndex = 3;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(127, 36);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(152, 22);
            this.txtNome.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(353, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Data Nascimento";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "País";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(354, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Doc ID / CC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Nome";
            // 
            // btnImprimir
            // 
            this.btnImprimir.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnImprimir.Image = ((System.Drawing.Image)(resources.GetObject("btnImprimir.Image")));
            this.btnImprimir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnImprimir.Location = new System.Drawing.Point(698, 34);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(99, 45);
            this.btnImprimir.TabIndex = 2;
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnImprimir.UseVisualStyleBackColor = false;
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnConfirmar.Location = new System.Drawing.Point(481, 34);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(108, 45);
            this.btnConfirmar.TabIndex = 1;
            this.btnConfirmar.Text = "Confirmar Reserva";
            this.btnConfirmar.UseVisualStyleBackColor = false;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnCancelar.Location = new System.Drawing.Point(127, 34);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(108, 45);
            this.btnCancelar.TabIndex = 0;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnImprimir);
            this.groupBox2.Controls.Add(this.btnConfirmar);
            this.groupBox2.Controls.Add(this.btnCancelar);
            this.groupBox2.Location = new System.Drawing.Point(22, 651);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(869, 96);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Origem";
            // 
            // btnPesquisarDatas
            // 
            this.btnPesquisarDatas.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnPesquisarDatas.Image = ((System.Drawing.Image)(resources.GetObject("btnPesquisarDatas.Image")));
            this.btnPesquisarDatas.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPesquisarDatas.Location = new System.Drawing.Point(386, 37);
            this.btnPesquisarDatas.Name = "btnPesquisarDatas";
            this.btnPesquisarDatas.Size = new System.Drawing.Size(247, 31);
            this.btnPesquisarDatas.TabIndex = 6;
            this.btnPesquisarDatas.Text = "Pesquisar Datas";
            this.btnPesquisarDatas.UseVisualStyleBackColor = false;
            this.btnPesquisarDatas.Click += new System.EventHandler(this.btnPesquisarDatas_Click);
            // 
            // gbxSelecaoVoos
            // 
            this.gbxSelecaoVoos.Controls.Add(this.btnSelecionarVoo);
            this.gbxSelecaoVoos.Controls.Add(this.cbxDataVolta);
            this.gbxSelecaoVoos.Controls.Add(this.cbxDataIda);
            this.gbxSelecaoVoos.Controls.Add(this.lblDataVolta);
            this.gbxSelecaoVoos.Controls.Add(this.rbIdaVolta);
            this.gbxSelecaoVoos.Controls.Add(this.rbIda);
            this.gbxSelecaoVoos.Controls.Add(this.cbxDestino);
            this.gbxSelecaoVoos.Controls.Add(this.label10);
            this.gbxSelecaoVoos.Controls.Add(this.cbxOrigem);
            this.gbxSelecaoVoos.Controls.Add(this.label2);
            this.gbxSelecaoVoos.Controls.Add(this.btnPesquisarDatas);
            this.gbxSelecaoVoos.Controls.Add(this.lblDataIda);
            this.gbxSelecaoVoos.Location = new System.Drawing.Point(22, 59);
            this.gbxSelecaoVoos.Name = "gbxSelecaoVoos";
            this.gbxSelecaoVoos.Size = new System.Drawing.Size(869, 183);
            this.gbxSelecaoVoos.TabIndex = 1;
            this.gbxSelecaoVoos.TabStop = false;
            this.gbxSelecaoVoos.Text = "Seleção de voo(s)";
            // 
            // btnSelecionarVoo
            // 
            this.btnSelecionarVoo.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnSelecionarVoo.Location = new System.Drawing.Point(722, 86);
            this.btnSelecionarVoo.Name = "btnSelecionarVoo";
            this.btnSelecionarVoo.Size = new System.Drawing.Size(88, 72);
            this.btnSelecionarVoo.TabIndex = 11;
            this.btnSelecionarVoo.Text = "Selecionar Voo";
            this.btnSelecionarVoo.UseVisualStyleBackColor = false;
            this.btnSelecionarVoo.Click += new System.EventHandler(this.btnSelecionarVoo_Click);
            // 
            // cbxDataVolta
            // 
            this.cbxDataVolta.FormattingEnabled = true;
            this.cbxDataVolta.Location = new System.Drawing.Point(481, 137);
            this.cbxDataVolta.Name = "cbxDataVolta";
            this.cbxDataVolta.Size = new System.Drawing.Size(152, 24);
            this.cbxDataVolta.TabIndex = 10;
            // 
            // cbxDataIda
            // 
            this.cbxDataIda.FormattingEnabled = true;
            this.cbxDataIda.Location = new System.Drawing.Point(481, 89);
            this.cbxDataIda.Name = "cbxDataIda";
            this.cbxDataIda.Size = new System.Drawing.Size(152, 24);
            this.cbxDataIda.TabIndex = 8;
            this.cbxDataIda.SelectedIndexChanged += new System.EventHandler(this.cbxDataIda_SelectedIndexChanged);
            // 
            // lblDataVolta
            // 
            this.lblDataVolta.AutoSize = true;
            this.lblDataVolta.Location = new System.Drawing.Point(383, 143);
            this.lblDataVolta.Name = "lblDataVolta";
            this.lblDataVolta.Size = new System.Drawing.Size(70, 16);
            this.lblDataVolta.TabIndex = 9;
            this.lblDataVolta.Text = "Data Volta";
            // 
            // rbIdaVolta
            // 
            this.rbIdaVolta.AutoSize = true;
            this.rbIdaVolta.Location = new System.Drawing.Point(127, 138);
            this.rbIdaVolta.Name = "rbIdaVolta";
            this.rbIdaVolta.Size = new System.Drawing.Size(90, 20);
            this.rbIdaVolta.TabIndex = 5;
            this.rbIdaVolta.TabStop = true;
            this.rbIdaVolta.Text = "Ida e volta";
            this.rbIdaVolta.UseVisualStyleBackColor = true;
            // 
            // rbIda
            // 
            this.rbIda.AutoSize = true;
            this.rbIda.Location = new System.Drawing.Point(32, 138);
            this.rbIda.Name = "rbIda";
            this.rbIda.Size = new System.Drawing.Size(67, 20);
            this.rbIda.TabIndex = 4;
            this.rbIda.TabStop = true;
            this.rbIda.Text = "Só ida";
            this.rbIda.UseVisualStyleBackColor = true;
            // 
            // cbxDestino
            // 
            this.cbxDestino.FormattingEnabled = true;
            this.cbxDestino.Location = new System.Drawing.Point(129, 87);
            this.cbxDestino.Name = "cbxDestino";
            this.cbxDestino.Size = new System.Drawing.Size(152, 24);
            this.cbxDestino.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Destino";
            // 
            // cbxOrigem
            // 
            this.cbxOrigem.FormattingEnabled = true;
            this.cbxOrigem.Location = new System.Drawing.Point(127, 38);
            this.cbxOrigem.Name = "cbxOrigem";
            this.cbxOrigem.Size = new System.Drawing.Size(152, 24);
            this.cbxOrigem.TabIndex = 1;
            this.cbxOrigem.SelectedIndexChanged += new System.EventHandler(this.cbxOrigem_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(303, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Reserva de Voo";
            // 
            // gbxItinerario
            // 
            this.gbxItinerario.Controls.Add(this.dataGridView1);
            this.gbxItinerario.Location = new System.Drawing.Point(22, 263);
            this.gbxItinerario.Name = "gbxItinerario";
            this.gbxItinerario.Size = new System.Drawing.Size(869, 163);
            this.gbxItinerario.TabIndex = 2;
            this.gbxItinerario.TabStop = false;
            this.gbxItinerario.Text = "O seu itinerário";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 21);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(843, 123);
            this.dataGridView1.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 601);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Nº Bilhete";
            // 
            // btnPesquisarNumBilhete
            // 
            this.btnPesquisarNumBilhete.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnPesquisarNumBilhete.Image = ((System.Drawing.Image)(resources.GetObject("btnPesquisarNumBilhete.Image")));
            this.btnPesquisarNumBilhete.Location = new System.Drawing.Point(242, 591);
            this.btnPesquisarNumBilhete.Name = "btnPesquisarNumBilhete";
            this.btnPesquisarNumBilhete.Size = new System.Drawing.Size(61, 37);
            this.btnPesquisarNumBilhete.TabIndex = 6;
            this.btnPesquisarNumBilhete.UseVisualStyleBackColor = false;
            this.btnPesquisarNumBilhete.Click += new System.EventHandler(this.btnPesquisarNumBilhete_Click);
            // 
            // lblTotalPagar
            // 
            this.lblTotalPagar.AutoSize = true;
            this.lblTotalPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalPagar.Location = new System.Drawing.Point(498, 591);
            this.lblTotalPagar.Name = "lblTotalPagar";
            this.lblTotalPagar.Size = new System.Drawing.Size(161, 29);
            this.lblTotalPagar.TabIndex = 7;
            this.lblTotalPagar.Text = "Total a pagar:";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(51, 632);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(340, 16);
            this.lblInfo.TabIndex = 8;
            this.lblInfo.Text = "Reserva será confirmada após receção do pagamento.";
            // 
            // txtNumBilhete
            // 
            this.txtNumBilhete.Location = new System.Drawing.Point(149, 598);
            this.txtNumBilhete.Name = "txtNumBilhete";
            this.txtNumBilhete.Size = new System.Drawing.Size(72, 22);
            this.txtNumBilhete.TabIndex = 5;
            this.txtNumBilhete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // FormReservaDeVoo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(903, 759);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblTotalPagar);
            this.Controls.Add(this.btnPesquisarNumBilhete);
            this.Controls.Add(this.txtNumBilhete);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gbxItinerario);
            this.Controls.Add(this.gbxDados);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbxSelecaoVoos);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormReservaDeVoo";
            this.Text = "Reserva de Voo";
            this.Load += new System.EventHandler(this.FormReservaDeVoo_Load);
            this.gbxDados.ResumeLayout(false);
            this.gbxDados.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.gbxSelecaoVoos.ResumeLayout(false);
            this.gbxSelecaoVoos.PerformLayout();
            this.gbxItinerario.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MaskedTextBox mtxtDataNascimento;
        private System.Windows.Forms.Label lblDataIda;
        private System.Windows.Forms.GroupBox gbxDados;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPesquisarDatas;
        private System.Windows.Forms.GroupBox gbxSelecaoVoos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxDestino;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbxOrigem;
        private System.Windows.Forms.RadioButton rbIdaVolta;
        private System.Windows.Forms.RadioButton rbIda;
        private System.Windows.Forms.Label lblDataVolta;
        private System.Windows.Forms.ComboBox cbxDataVolta;
        private System.Windows.Forms.ComboBox cbxDataIda;
        private System.Windows.Forms.Button btnSelecionarVoo;
        private System.Windows.Forms.GroupBox gbxItinerario;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtDocId;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.ComboBox cbxPais;
        private System.Windows.Forms.ComboBox cbxTitulo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnPesquisarNumBilhete;
        private System.Windows.Forms.Label lblTotalPagar;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.TextBox txtNumBilhete;
    }
}