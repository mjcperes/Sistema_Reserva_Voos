﻿namespace ReservaVoos
{
    partial class FormVoos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVoos));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdVoo = new System.Windows.Forms.TextBox();
            this.btnPesquisarIdVoo = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbxMatricula = new System.Windows.Forms.ComboBox();
            this.cbxIdRota = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.btnGravar = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNumLugares = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.mtxtHoraChegada = new System.Windows.Forms.MaskedTextBox();
            this.mtxtHoraPartida = new System.Windows.Forms.MaskedTextBox();
            this.rbCancelado = new System.Windows.Forms.RadioButton();
            this.rbFechado = new System.Windows.Forms.RadioButton();
            this.rbPlaneado = new System.Windows.Forms.RadioButton();
            this.dtpDataVoo = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtIdVoo);
            this.groupBox3.Controls.Add(this.btnPesquisarIdVoo);
            this.groupBox3.Location = new System.Drawing.Point(20, 54);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(549, 90);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "ID Voo";
            // 
            // txtIdVoo
            // 
            this.txtIdVoo.Location = new System.Drawing.Point(153, 38);
            this.txtIdVoo.Name = "txtIdVoo";
            this.txtIdVoo.Size = new System.Drawing.Size(113, 22);
            this.txtIdVoo.TabIndex = 1;
            // 
            // btnPesquisarIdVoo
            // 
            this.btnPesquisarIdVoo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnPesquisarIdVoo.Image = ((System.Drawing.Image)(resources.GetObject("btnPesquisarIdVoo.Image")));
            this.btnPesquisarIdVoo.Location = new System.Drawing.Point(408, 23);
            this.btnPesquisarIdVoo.Name = "btnPesquisarIdVoo";
            this.btnPesquisarIdVoo.Size = new System.Drawing.Size(108, 37);
            this.btnPesquisarIdVoo.TabIndex = 2;
            this.btnPesquisarIdVoo.UseVisualStyleBackColor = false;
            this.btnPesquisarIdVoo.Click += new System.EventHandler(this.btnPesquisarIdVoo_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(330, 170);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Hora Chegada";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Hora Partida";
            // 
            // cbxMatricula
            // 
            this.cbxMatricula.FormattingEnabled = true;
            this.cbxMatricula.Location = new System.Drawing.Point(424, 40);
            this.cbxMatricula.Name = "cbxMatricula";
            this.cbxMatricula.Size = new System.Drawing.Size(92, 24);
            this.cbxMatricula.TabIndex = 3;
            // 
            // cbxIdRota
            // 
            this.cbxIdRota.FormattingEnabled = true;
            this.cbxIdRota.Location = new System.Drawing.Point(153, 40);
            this.cbxIdRota.Name = "cbxIdRota";
            this.cbxIdRota.Size = new System.Drawing.Size(113, 24);
            this.cbxIdRota.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 294);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Estado";
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnAtualizar.Location = new System.Drawing.Point(219, 33);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(108, 45);
            this.btnAtualizar.TabIndex = 1;
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.UseVisualStyleBackColor = false;
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);
            // 
            // btnGravar
            // 
            this.btnGravar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnGravar.Location = new System.Drawing.Point(408, 33);
            this.btnGravar.Name = "btnGravar";
            this.btnGravar.Size = new System.Drawing.Size(108, 45);
            this.btnGravar.TabIndex = 2;
            this.btnGravar.Text = "Gravar";
            this.btnGravar.UseVisualStyleBackColor = false;
            this.btnGravar.Click += new System.EventHandler(this.btnGravar_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnAtualizar);
            this.groupBox2.Controls.Add(this.btnGravar);
            this.groupBox2.Controls.Add(this.btnCancelar);
            this.groupBox2.Location = new System.Drawing.Point(20, 495);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(549, 96);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnCancelar.Location = new System.Drawing.Point(15, 33);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(108, 45);
            this.btnCancelar.TabIndex = 0;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(151, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Inserir / Atualizar Voos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(330, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Matrícula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "ID Rota";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtNumLugares);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.mtxtHoraChegada);
            this.groupBox1.Controls.Add(this.mtxtHoraPartida);
            this.groupBox1.Controls.Add(this.rbCancelado);
            this.groupBox1.Controls.Add(this.rbFechado);
            this.groupBox1.Controls.Add(this.rbPlaneado);
            this.groupBox1.Controls.Add(this.dtpDataVoo);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cbxMatricula);
            this.groupBox1.Controls.Add(this.cbxIdRota);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(20, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(549, 339);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // txtNumLugares
            // 
            this.txtNumLugares.Location = new System.Drawing.Point(153, 234);
            this.txtNumLugares.Name = "txtNumLugares";
            this.txtNumLugares.Size = new System.Drawing.Size(61, 22);
            this.txtNumLugares.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "N\' Lugares";
            // 
            // mtxtHoraChegada
            // 
            this.mtxtHoraChegada.Location = new System.Drawing.Point(455, 167);
            this.mtxtHoraChegada.Mask = "00:00";
            this.mtxtHoraChegada.Name = "mtxtHoraChegada";
            this.mtxtHoraChegada.Size = new System.Drawing.Size(61, 22);
            this.mtxtHoraChegada.TabIndex = 9;
            this.mtxtHoraChegada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtxtHoraChegada.ValidatingType = typeof(System.DateTime);
            // 
            // mtxtHoraPartida
            // 
            this.mtxtHoraPartida.Location = new System.Drawing.Point(153, 167);
            this.mtxtHoraPartida.Mask = "00:00";
            this.mtxtHoraPartida.Name = "mtxtHoraPartida";
            this.mtxtHoraPartida.Size = new System.Drawing.Size(61, 22);
            this.mtxtHoraPartida.TabIndex = 7;
            this.mtxtHoraPartida.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtxtHoraPartida.ValidatingType = typeof(System.DateTime);
            // 
            // rbCancelado
            // 
            this.rbCancelado.AutoSize = true;
            this.rbCancelado.Location = new System.Drawing.Point(422, 294);
            this.rbCancelado.Name = "rbCancelado";
            this.rbCancelado.Size = new System.Drawing.Size(94, 20);
            this.rbCancelado.TabIndex = 15;
            this.rbCancelado.TabStop = true;
            this.rbCancelado.Text = "Cancelado";
            this.rbCancelado.UseVisualStyleBackColor = true;
            // 
            // rbFechado
            // 
            this.rbFechado.AutoSize = true;
            this.rbFechado.Location = new System.Drawing.Point(289, 290);
            this.rbFechado.Name = "rbFechado";
            this.rbFechado.Size = new System.Drawing.Size(82, 20);
            this.rbFechado.TabIndex = 14;
            this.rbFechado.TabStop = true;
            this.rbFechado.Text = "Fechado";
            this.rbFechado.UseVisualStyleBackColor = true;
            // 
            // rbPlaneado
            // 
            this.rbPlaneado.AutoSize = true;
            this.rbPlaneado.Location = new System.Drawing.Point(153, 290);
            this.rbPlaneado.Name = "rbPlaneado";
            this.rbPlaneado.Size = new System.Drawing.Size(87, 20);
            this.rbPlaneado.TabIndex = 13;
            this.rbPlaneado.TabStop = true;
            this.rbPlaneado.Text = "Planeado";
            this.rbPlaneado.UseVisualStyleBackColor = true;
            // 
            // dtpDataVoo
            // 
            this.dtpDataVoo.Location = new System.Drawing.Point(153, 98);
            this.dtpDataVoo.Name = "dtpDataVoo";
            this.dtpDataVoo.Size = new System.Drawing.Size(218, 22);
            this.dtpDataVoo.TabIndex = 5;
            this.dtpDataVoo.ValueChanged += new System.EventHandler(this.dtpDataVoo_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Data Voo";
            // 
            // FormVoos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 603);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormVoos";
            this.Text = "Planeamento de Voos";
            this.Load += new System.EventHandler(this.FormVoos_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdVoo;
        private System.Windows.Forms.Button btnPesquisarIdVoo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbxMatricula;
        private System.Windows.Forms.ComboBox cbxIdRota;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.Button btnGravar;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dtpDataVoo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rbCancelado;
        private System.Windows.Forms.RadioButton rbFechado;
        private System.Windows.Forms.RadioButton rbPlaneado;
        private System.Windows.Forms.MaskedTextBox mtxtHoraPartida;
        private System.Windows.Forms.MaskedTextBox mtxtHoraChegada;
        private System.Windows.Forms.TextBox txtNumLugares;
        private System.Windows.Forms.Label label6;
    }
}