﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ReservaVoos
{
    public partial class FormTarifas : Form
    {
        DBConnect ligacao = new DBConnect();
        string auxTipo;
        public FormTarifas()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (ligacao.ValidateTarifa(txtIdTarifa.Text) == false)
                {
                    if (ligacao.InsertTarifa(txtIdTarifa.Text.ToUpper(), txtDescricaoTarifa.Text, txtValorKm.Text, auxTipo))
                    {
                        MessageBox.Show("Gravado com sucesso!");
                        Limpar();
                        txtIdTarifa.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Erro na gravação do registo!");
                    }
                }
                else
                {
                    MessageBox.Show("Código de tarifa já existe!");
                }
            }
        }

        private bool VerificarCampos()
        {
            txtIdTarifa.Text = Geral.TirarEspacos(txtIdTarifa.Text);
            if (txtIdTarifa.Text.Length < 1)
            {
                MessageBox.Show("Erro no campo Tarifa!");
                txtIdTarifa.Focus();
                return false;
            }

            txtDescricaoTarifa.Text = Geral.TirarEspacos(txtDescricaoTarifa.Text);
            if (txtDescricaoTarifa.Text.Length < 4)
            {
                MessageBox.Show("Erro no campo Descrição Tarifa!");
                txtDescricaoTarifa.Focus();
                return false;
            }

            txtValorKm.Text = Geral.TirarEspacos(txtValorKm.Text);
            bool verificaFloat = float.TryParse(txtValorKm.Text, out _); // verificar se é um float
            // substituição da vírgula por ponto. O separador decimal é a vírgula para o sistema, mas o é o ponto para a BD
            txtValorKm.Text = txtValorKm.Text.Replace(',', '.');            
            if (txtValorKm.Text.Length < 1 || verificaFloat == false)
            {
                MessageBox.Show("Erro no campo Valor Km!");
                txtValorKm.Focus();
                return false;
            }

            auxTipo = Geral.TirarEspacos(auxTipo);            
            if (auxTipo != "OW" && auxTipo != "RT")
            {
                MessageBox.Show("Erro no campo Tipo!");
                cbxTipo.Focus();
                return false;
            }

            return true;
        }

        private void Limpar()
        {
            txtIdTarifa.Text = "";
            txtDescricaoTarifa.Text = "";
            txtValorKm.Text = "";
            cbxTipo.Text = "";
        }        

        private void btnPesquisarTarifa_Click(object sender, EventArgs e)
        {
            string descricaoTarifa = "", valorKm = "", tipo = string.Empty;

            if (ligacao.PesquisarTarifa(txtIdTarifa.Text, ref descricaoTarifa, ref valorKm, ref tipo))
            {
                txtDescricaoTarifa.Text = descricaoTarifa;
                txtValorKm.Text = valorKm;                
                cbxTipo.Text = tipo;
            }
            else
            {
                MessageBox.Show("Código de tarifa não encontrado!");
                Limpar();
            }
        }

        private void cbxTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = cbxTipo.SelectedItem.ToString(); // Passa valor da combobox para uma string            

            auxTipo = selectedItem;
        }

        private void FormTarifas_Load(object sender, EventArgs e)
        {            
            cbxTipo.Items.Add("OW");
            cbxTipo.Items.Add("RT");                     
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpar();
            txtIdTarifa.Focus();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (MessageBox.Show("Deseja atualizar a tarifa com o ID " + txtIdTarifa.Text, "Atualizar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) ==
                DialogResult.Yes)
                {
                    if (ligacao.ValidateTarifa(txtIdTarifa.Text))
                    {
                        if (ligacao.UpdateTarifa(txtIdTarifa.Text, txtDescricaoTarifa.Text, txtValorKm.Text, auxTipo))
                        {
                            MessageBox.Show("Gravado com sucesso!");
                            Limpar();
                            txtIdTarifa.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Erro na gravação do registo!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("ID da tarifa não existe!");
                    }
                }
            }
        }
    }
}
