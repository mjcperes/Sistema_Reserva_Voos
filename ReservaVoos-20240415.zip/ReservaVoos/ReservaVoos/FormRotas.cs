﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReservaVoos
{
    public partial class FormRotas : Form
    {
        DBConnect ligacao = new DBConnect();
        string auxAerPartida = "";
        string auxAerChegada = "";
        string auxOW = "";
        string auxRT = "";

        public FormRotas()
        {
            InitializeComponent();
        }

        // É chamado o evento de carregamento do formulário para ligação e preenchimento das combobox
        private void FormRotas_Load(object sender, EventArgs e)
        {
            //DesativarControlos();

            //btnAtualizar.Enabled = false;

            this.AcceptButton = this.btnPesquisarIdRota;

            ligacao.PreencherComboAerop(ref cbxAeropPartida); // Preenchimento das comboboxes
            ligacao.PreencherComboAerop(ref cbxAeropChegada);
            ligacao.PreencherComboTarifa(ref cbxOW, "OW");
            ligacao.PreencherComboTarifa(ref cbxRT, "RT");
        }
        //private void DesativarControlos()
        //{            
        //    cbxAeropPartida.SelectedItem = null; // limpa a combobox. Caso se pretenda que fique apenas inativo mas com dados não inserir este código
        //    cbxAeropChegada.SelectedItem = null;
        //    txtDistancia.ReadOnly = true;
        //}

        private void btnPesquisarIdRota_Click(object sender, EventArgs e)
        {
            string aeropPartida = string.Empty, cIataPartida = string.Empty, aeropChegada = string.Empty, cIataChegada = string.Empty,
                distancia = "", tarifa_OW = string.Empty, tarifa_RT = string.Empty;

            if (ligacao.PesquisarIdRota(txtIdRota.Text.ToUpper(), ref aeropPartida, ref cIataPartida, ref aeropChegada, ref cIataChegada, ref distancia,
                ref tarifa_OW, ref tarifa_RT))
            {
                cbxAeropPartida.Text = aeropPartida + " - " + cIataPartida;
                cbxAeropChegada.Text = aeropChegada + " - " + cIataChegada;
                txtDistancia.Text = distancia;
                cbxOW.Text = tarifa_OW;
                cbxRT.Text = tarifa_RT;

                //btnAtualizar.Enabled = true;
                
                cbxAeropPartida.Items.Clear();
                cbxAeropChegada.Items.Clear();
                ligacao.PreencherComboAerop(ref cbxAeropPartida); // Preenchimento das comboboxes
                ligacao.PreencherComboAerop(ref cbxAeropChegada);
            }
            else
            {
                MessageBox.Show("Rota não encontrada!");
                Limpar();
            }
        }

        private void Limpar()
        {
            txtIdRota.Text = string.Empty;
            cbxAeropPartida.Text = string.Empty;
            cbxAeropChegada.Text = string.Empty;
            txtDistancia.Text = string.Empty;
            cbxOW.Text = string.Empty;
            cbxRT.Text = string.Empty;
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                if (MessageBox.Show("Deseja atualizar a rota com o ID " + txtIdRota.Text, "Atualizar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) ==
                DialogResult.Yes)
                {
                    if (ligacao.ValidateRota(txtIdRota.Text))
                    {
                        if (ligacao.UpdateRota(txtIdRota.Text, auxAerPartida, auxAerChegada, txtDistancia.Text, auxOW, auxRT))
                        {
                            MessageBox.Show("Gravado com sucesso!");
                            Limpar();
                            txtIdRota.Focus();
                        }
                        else
                        {
                            MessageBox.Show("Erro na gravação do registo!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("ID da rota não existe!");
                    }
                }
            }
        }

        private bool VerificarCampos()
        {
            txtIdRota.Text = Geral.TirarEspacos(txtIdRota.Text);
            if (txtIdRota.Text.Length < 4)
            {
                MessageBox.Show("Erro no campo ID Rota!");
                txtIdRota.Focus();
                return false;
            }

            auxAerPartida = Geral.TirarEspacos(auxAerPartida);
            if (auxAerPartida.Length < 3)
            {
                MessageBox.Show("Erro no campo Aeroporto de Partida!");
                cbxAeropPartida.Focus();
                return false;
            }

            auxAerChegada = Geral.TirarEspacos(auxAerChegada);
            if (auxAerChegada.Length < 3)
            {
                MessageBox.Show("Erro no campo Aeroporto de Chegada!");
                cbxAeropChegada.Focus();
                return false;
            }            

            txtDistancia.Text = Geral.TirarEspacos(txtDistancia.Text);
            bool verificaInt = int.TryParse(txtDistancia.Text, out _);
            if (txtDistancia.Text.Length < 1 || verificaInt == false)
            {
                MessageBox.Show("Erro no campo Distancia!");
                txtDistancia.Focus();
                return false;
            }

            auxOW = Geral.TirarEspacos(auxOW);
            if (auxOW.Length < 1)
            {
                MessageBox.Show("Erro no campo Ida (OW)!");
                cbxOW.Focus();
                return false;
            }

            auxRT = Geral.TirarEspacos(auxRT);
            if (auxOW.Length < 1)
            {
                MessageBox.Show("Erro no campo Ida e volta (RT)!");
                cbxRT.Focus();
                return false;
            }

            return true;
        }

        private void cbxAeropPartida_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxAeropPartida.SelectedItem == null) // se a combobox == null, não fazer nada (return pára a execução do método)
            {
                return;
            }

            string selectedItem = cbxAeropPartida.SelectedItem.ToString(); // Passa valor da combobox para uma string            

            if (selectedItem.IndexOf("-") != -1) // se não existirem "-" retorna -1. Nest caso a condição é se a string tiver "-"
            {
                auxAerPartida = selectedItem.Substring(0, selectedItem.LastIndexOf("-")-1);                
            }
            else
            {
                MessageBox.Show("Aeroporto de partida não encontrado!");
                Limpar();
            }
        }

        private void cbxAeropChegada_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxAeropChegada.SelectedItem == null) // se a combobox == null, não fazer nada (return pára a execução do método)
            {
                return;
            }

            string selectedItem = cbxAeropChegada.SelectedItem.ToString(); // Passa valor da combobox para uma string            

            if (selectedItem.IndexOf("-") != -1) // se não existirem "-" retorna -1. Nest caso a condição é se a string tiver "-"
            {
                auxAerChegada = selectedItem.Substring(0, selectedItem.LastIndexOf("-") - 1);
            }
            else
            {
                MessageBox.Show("Aeroporto de chegada não encontrado!");
                Limpar();
            }
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (VerificarCampos())
            {
                // se não existe o id de rota e se não existe o mesmo percurso
                if (ligacao.ValidateRota(txtIdRota.Text) == false && ligacao.CheckPercurso(auxAerPartida, auxAerChegada) == false)
                {
                    if (ligacao.InsertRota(txtIdRota.Text.ToUpper(), auxAerPartida, auxAerChegada, txtDistancia.Text, auxOW, auxRT))
                    {
                        MessageBox.Show("Gravado com sucesso!");
                        Limpar();
                        txtIdRota.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Erro na gravação do registo!");
                    }
                }
                else
                {
                    MessageBox.Show("ID da rota ou percurso já existem!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpar();
            txtIdRota.Focus();
        }

        private void cbxOW_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxOW.SelectedItem == null) // se a combobox == null, não fazer nada (return pára a execução do método)
            {
                return;
            }

            string selectedItem = cbxOW.SelectedItem.ToString(); // Passa valor da combobox para uma string            

            auxOW = selectedItem;            

        }

        private void cbxRT_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxRT.SelectedItem == null) // se a combobox == null, não fazer nada (return pára a execução do método)
            {
                return;
            }

            string selectedItem = cbxRT.SelectedItem.ToString(); // Passa valor da combobox para uma string            

            auxRT = selectedItem;
        }
    }
}
