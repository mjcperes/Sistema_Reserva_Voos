﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReservaVoos
{
    public partial class FormPrincipal : Form
    {
        FormDestinos formDestinos = new FormDestinos();
        FormListarDestinos formListarDestinos = new FormListarDestinos();
        FormAeronaves formAeronaves = new FormAeronaves();
        FormListarAeronaves formListarAeronaves = new FormListarAeronaves();
        FormRotas formRotas = new FormRotas();
        FormListarRotas formListarRotas = new FormListarRotas();
        FormTarifas formTarifas = new FormTarifas();
        FormListarTarifas formListarTarifas = new FormListarTarifas();
        FormVoos formVoos = new FormVoos();
        FormListarVoos formListarVoos = new FormListarVoos();
        FormReservaDeVoo formReservaDeVoo = new FormReservaDeVoo();
        FormListaPassageiros formListaPassageiros = new FormListaPassageiros();
        FormListaVendas formListaVendas = new FormListaVendas();

        //Localização do FormReservaDeVoo
        public Point GetFormReservaDeVooLocation()
        {
            return formReservaDeVoo.Location;
        }

        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void destinosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // FormDestinos formDestinos = new FormDestinos();
            // Se o objeto for declarado diretamente dentro da opção "Destinos" está sempre a abrir novas janelas (efeito cogumelo)

            if (formDestinos.IsDisposed)
            {
                formDestinos = new FormDestinos();
            }
            formDestinos.MdiParent = this; // formPrincipal (this) é o pai do formDestinos
            formDestinos.StartPosition = FormStartPosition.Manual;
            formDestinos.Location = new Point((this.ClientSize.Width - formDestinos.Width) / 2,
                (this.ClientSize.Height - formDestinos.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formDestinos.Show();
            formDestinos.Activate();            
        }        

        private void listarDestinosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (formListarDestinos.IsDisposed)
            {
                formListarDestinos = new FormListarDestinos();
            }
            formListarDestinos.MdiParent = this; // formPrincipal (this) é o pai do formListarDestinos
            formListarDestinos.StartPosition = FormStartPosition.Manual;
            formListarDestinos.Location = new Point((this.ClientSize.Width - formListarDestinos.Width) / 2,
                (this.ClientSize.Height - formListarDestinos.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListarDestinos.Show();
            formListarDestinos.Activate();
        }

        private void aeronavesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formAeronaves.IsDisposed)
            {
                formAeronaves = new FormAeronaves();
            }
            formAeronaves.MdiParent = this; // formPrincipal (this) é o pai do formAeronaves
            formAeronaves.StartPosition = FormStartPosition.Manual;
            formAeronaves.Location = new Point((this.ClientSize.Width - formAeronaves.Width) / 2,
                (this.ClientSize.Height - formAeronaves.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formAeronaves.Show();
            formAeronaves.Activate();
        }

        private void listarAeronavesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formListarAeronaves.IsDisposed)
            {
                formListarAeronaves = new FormListarAeronaves();
            }
            formListarAeronaves.MdiParent = this; // formPrincipal (this) é o pai do formListarAeronaves
            formListarAeronaves.StartPosition = FormStartPosition.Manual;
            formListarAeronaves.Location = new Point((this.ClientSize.Width - formListarAeronaves.Width) / 2,
                (this.ClientSize.Height - formListarAeronaves.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListarAeronaves.Show();
            formListarAeronaves.Activate();
        }

        private void rotasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formRotas.IsDisposed)
            {
                formRotas = new FormRotas();
            }
            formRotas.MdiParent = this; // formPrincipal (this) é o pai do formRotas
            formRotas.StartPosition = FormStartPosition.Manual;
            formRotas.Location = new Point((this.ClientSize.Width - formRotas.Width) / 2,
                (this.ClientSize.Height - formRotas.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formRotas.Show();
            formRotas.Activate();
        }

        private void listarAsNossasRotasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formListarRotas.IsDisposed)
            {
                formListarRotas = new FormListarRotas();
            }
            formListarRotas.MdiParent = this; // formPrincipal (this) é o pai do formListarRotas
            formListarRotas.StartPosition = FormStartPosition.Manual;
            formListarRotas.Location = new Point((this.ClientSize.Width - formListarRotas.Width) / 2,
                (this.ClientSize.Height - formListarRotas.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListarRotas.Show();
            formListarRotas.Activate();
        }

        private void tarifasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formTarifas.IsDisposed)
            {
                formTarifas = new FormTarifas();
            }
            formTarifas.MdiParent = this; // formPrincipal (this) é o pai do formTarifas
            formTarifas.StartPosition = FormStartPosition.Manual;
            formTarifas.Location = new Point((this.ClientSize.Width - formTarifas.Width) / 2,
                (this.ClientSize.Height - formTarifas.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formTarifas.Show();
            formTarifas.Activate();
        }

        private void listarTarifasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formListarTarifas.IsDisposed)
            {
                formListarTarifas = new FormListarTarifas();
            }
            formListarTarifas.MdiParent = this; // formPrincipal (this) é o pai do formListarTarifas
            formListarTarifas.StartPosition = FormStartPosition.Manual;
            formListarTarifas.Location = new Point((this.ClientSize.Width - formListarTarifas.Width) / 2,
                (this.ClientSize.Height - formListarTarifas.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListarTarifas.Show();
            formListarTarifas.Activate();
        }

        private void voosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formVoos.IsDisposed)
            {
                formVoos = new FormVoos();
            }
            formVoos.MdiParent = this; // formPrincipal (this) é o pai do formVoos
            formVoos.StartPosition = FormStartPosition.Manual;
            formVoos.Location = new Point((this.ClientSize.Width - formVoos.Width) / 2,
                (this.ClientSize.Height - formVoos.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formVoos.Show();
            formVoos.Activate();
        }

        private void listarVoosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formListarVoos.IsDisposed)
            {
                formListarVoos = new FormListarVoos();
            }
            formListarVoos.MdiParent = this; // formPrincipal (this) é o pai do formListarVoos
            formListarVoos.StartPosition = FormStartPosition.Manual;
            formListarVoos.Location = new Point((this.ClientSize.Width - formListarVoos.Width) / 2,
                (this.ClientSize.Height - formListarVoos.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListarVoos.Show();
            formListarVoos.Activate();
        }

        private void reservaDeVooToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formReservaDeVoo.IsDisposed)
            {
                formReservaDeVoo = new FormReservaDeVoo();
            }
            formReservaDeVoo.MdiParent = this; // formPrincipal (this) é o pai do formReservaDeVoo
            formReservaDeVoo.StartPosition = FormStartPosition.Manual;
            formReservaDeVoo.Location = new Point((this.ClientSize.Width - formReservaDeVoo.Width) / 2,
                (this.ClientSize.Height - formReservaDeVoo.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formReservaDeVoo.Show();
            formReservaDeVoo.Activate();
        }

        private void listaPassageirosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formListaPassageiros.IsDisposed)
            {
                formListaPassageiros = new FormListaPassageiros();
            }
            formListaPassageiros.MdiParent = this; // formPrincipal (this) é o pai do formListaPassageiros
            formListaPassageiros.StartPosition = FormStartPosition.Manual;
            formListaPassageiros.Location = new Point((this.ClientSize.Width - formListaPassageiros.Width) / 2,
                (this.ClientSize.Height - formListaPassageiros.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListaPassageiros.Show();
            formListaPassageiros.Activate();
        }

        private void vendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (formListaVendas.IsDisposed)
            {
                formListaVendas = new FormListaVendas();
            }
            formListaVendas.MdiParent = this; // formPrincipal (this) é o pai do formListaVendas
            formListaVendas.StartPosition = FormStartPosition.Manual;
            formListaVendas.Location = new Point((this.ClientSize.Width - formListaVendas.Width) / 2,
                (this.ClientSize.Height - formListaVendas.Height) / 3);
            // Fechando a janela destrói o objeto. Sem a condição If acima, se for aberto novamente dá erro
            formListaVendas.Show();
            formListaVendas.Activate();
        }
    }
}
